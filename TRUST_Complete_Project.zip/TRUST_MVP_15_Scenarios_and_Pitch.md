# TRUST — A Game That Teaches People How to Survive in the Digital World

**Genre:** Educational Simulation / Puzzle / Real-Life Decision Making

**Tagline:** *“One wrong decision can change your life. One game can teach you how to make the right one.”*

## The Big Idea

Imagine a free mobile game that teaches millions of people how to protect themselves from online scams, financial fraud, misinformation, identity theft, and digital manipulation.

Instead of watching boring educational videos, players experience realistic situations through interactive stories, simulated conversations, and challenging decisions.

For example, a player receives a message:

> “Your bank account has been locked. Click this link within 10 minutes to prevent permanent suspension.”

The player must decide what to do. Every choice leads to realistic consequences, and the game teaches players how to recognize danger before they encounter it in real life.

But the game goes beyond identifying scams. It teaches **critical thinking, emotional awareness, and decision-making under pressure.**

## What Makes It Different?

Most educational games test what people already know.

**TRUST teaches people how to think when they don't know the answer.**

Players will face situations involving fake job offers, cryptocurrency scams, impersonation, social engineering, AI-generated voices, and deceptive online relationships.

The game rewards careful verification, asking questions, and recognizing manipulation instead of simply selecting the correct answer.

As players progress, scenarios become more sophisticated, reflecting the kinds of threats people encounter in an increasingly AI-driven world.

## How Could It Change the World?

### Protect Vulnerable People

Help teenagers, older adults, and people with limited digital literacy recognize manipulation before losing money or personal information.

### Make Digital Education Accessible

Offer free lessons in multiple languages, including offline gameplay for communities with limited internet access.

### Build Critical-Thinking Skills

Teach players to question suspicious claims, verify sources, and make better decisions beyond the game itself.

### Create Measurable Social Impact

Partner with schools, banks, and nonprofit organizations to evaluate whether gameplay improves people's ability to detect real-world scams.

## The First Version (MVP)

The initial version doesn't require expensive 3D graphics or advanced AI.

Build a lightweight mobile game using Unity, with simulated smartphone interfaces, branching dialogue, and 15 carefully designed scenarios.

Each session lasts 3–5 minutes. Players make decisions, see the consequences, and learn practical techniques they can immediately apply in everyday life.

Later, AI could generate new educational scenarios under expert-reviewed safety rules, helping the game evolve as digital threats change.

## Business Model

The core game remains free for individuals.

Revenue could come from educational licensing to schools, cybersecurity training programs, banks, insurance companies, and organizations that want to protect their customers or employees.

This creates an opportunity to build a sustainable business **without making the people who need protection most pay for it.**

## The Long-Term Vision

TRUST could become a global platform for practical digital literacy.

Imagine a world where every teenager learns to recognize manipulation before opening their first bank account, every older adult can practice identifying scams in a safe environment, and millions of people become more confident navigating an increasingly complex digital world.

The success of this project wouldn't be measured only in downloads or revenue.

It would be measured in people who avoided being scammed, families who protected their savings, and communities that became safer through education.

**The mission:**

*“Build a world where technology empowers people instead of exploiting their vulnerabilities — one decision, one lesson, and one player at a time.”*

---

# Part II — Detailed MVP Game Design

**Document status:** Concept + implementable MVP design (v1.0)  
**Working title:** TRUST  
**Platform:** Android first, then iOS  
**Format:** Portrait, simulated mobile operating system; text-first interactive thriller  
**Audience:** Teenagers (with age-appropriate content), young adults, families, and older adults  
**Language:** English first; all dialogue externalized for localization  
**Core promise:** *Feel the pressure of a digital trap in a safe game, then learn the move that protects you in real life.*

## 1. Design Philosophy: A Thriller Disguised as a Life Skill

**This is not a multiple-choice cybersecurity exam.** Players enter believable social situations, hear other characters, uncover evidence, make decisions, and experience consequences. The fun comes from tension, curiosity, surprising reveals, character interactions, and the satisfaction of spotting a trap.

### The 60-second player loop

1. **Hook (10–20 sec):** A message, call, job offer, or social post creates an emotionally charged question.
2. **Investigate (30–90 sec):** Inspect simulated apps, profiles, receipts, timestamps, domains, and conversation history.
3. **Choose (20–40 sec):** Respond, verify, ignore, pause, or ask for more information. Options are meaningful, not just “good” vs “obviously stupid.”
4. **Consequence (20–40 sec):** Watch the fictional story respond to your decision. Wrong moves are recoverable in the game.
5. **Reveal (20–40 sec):** See what was known, what remained uncertain, and which verification habit transfers to real life.
6. **Replay/Share (optional):** Try an alternative route or share a spoiler-free challenge card.

**MVP target:** Most scenarios 3–5 minutes; some advanced cases 5–7 minutes. This is a design target to validate during playtesting, not a measured result.

### One important rule: Reward verification, not cynicism

The game must not teach players that everyone is lying or that “always block people” is the winning strategy. Genuine alerts, real charity appeals, legitimate urgent situations, and ordinary mistakes must sometimes appear. The highest-rated action is usually **verify through a trusted, independent channel**, then make a proportionate decision.

### Gameplay vocabulary

- **Inspect:** Tap a message header, timeline, transaction record, QR source, profile history, or app permission.
- **Verify:** Use a known contact, a saved official app, a previously trusted website, or an established workplace process.
- **Respond:** Choose an in-world message or action. The player never types real credentials or contacts real organizations.
- **Pause:** Stop an urgent action to get more context. This is a deliberate skill, not a “skip” button.
- **Recover:** After a bad decision, select the next-best protective response. Recovery should earn partial credit.

### Scoring (simple, understandable)

Each level earns up to **three shields**:

| Shield | Earned by | What the player learns |
|---|---|---|
| 🔎 Evidence | Finding a meaningful clue | Don't rely on surface appearance |
| 📞 Verification | Checking through an independent channel | Separate a claim from proof |
| 🛡️ Protection | Taking a proportionate protective action | Protect money, identity, access, and relationships |

A player may earn only 1–2 shields and still finish the story. Never reward speed alone; time pressure is part of the fiction, not a mandatory accessibility barrier.

### Campaign structure

| Chapter | Levels | Theme | Emotional arc |
|---|---|---|---|
| I. The Inbox | 01–05 | Everyday digital traps | “I recognize this.” → “I didn't expect that.” |
| II. The Human Factor | 06–10 | Trust, fear, hope, and persuasion | “I know what to check.” → “But what if I care?” |
| III. The Bigger Picture | 11–15 | Misinformation, institutions, and combined attacks | “I can protect myself.” → “I can help others.” |

---

# Chapter I — The Inbox

## Scenario 01 — The Bank Alert

**Difficulty:** 1/5  
**Duration target:** 3 min  
**Primary skill:** Responding to urgent financial messages without trusting the message's own instructions  
**Emotional trigger:** Fear of losing access to savings  
**UI assets:** SMS thread, mock bank app, transaction history, call-log screen

### Opening scene

The phone vibrates during an ordinary morning. A notification appears from an unfamiliar number:

> **ACCOUNT SECURITY:** A suspicious transfer of $680 was detected. Your account will be restricted in 10 minutes. Verify immediately: `secure-check.example.com`

A second message arrives:

> **Support Agent:** This is urgent. Please respond now so we can stop the transfer.

The player has a mock banking app already installed. Its icon looks familiar, but the text message's website also looks professionally written.

### Playable beats and decisions

**Beat A — First reaction:**

- **A.** Tap the link in the message. → A convincing but fictional sign-in page asks for username, password, and a one-time code. A warning-free appearance is *not* proof of authenticity.
- **B.** Open the saved bank app directly. → Transaction history shows no pending $680 transfer. A generic security notice is visible, encouraging direct contact for uncertainty.
- **C.** Reply “Are you really the bank?” → The sender immediately says yes and repeats the threat; confirmation from the claimant proves nothing.
- **D.** Delete the text without checking. → No data is exposed, but the player misses the chance to verify whether there is a genuine problem.

**Beat B — Finish the investigation:** The player can contact support using the number already inside the simulated banking app, or follow instructions from the message. The official channel confirms that the SMS is not theirs.

### Endings

- **Best:** Open the existing bank app, then verify through its official support. **3 shields.**
- **Mixed:** Ignore the message and make no payment or disclosure. **1–2 shields** because the player stayed safe but did not establish what happened.
- **Risky:** Enter information on the linked page. A fictional warning later reveals an attempted account takeover; the player can practice changing credentials and contacting the bank. **0–1 shields.**

### Debrief reveal

> “Urgency was the trap. A message can describe a real-sounding emergency while pointing to a fake solution. You don't need to decide whether the sender is honest; you need an independent route to the truth.”

**Transferable habit:** Open the bank's saved app or use an independently obtained contact method. Never provide an OTP because a message or caller demands it.

**Replay twist:** On replay, the bank app *does* display a legitimate account-security alert. The correct move is still independent verification, not blind dismissal.

**Implementation notes:** Two SMS bubbles, one interactive fake page, one bank-app ledger, and one official-support response. No real bank branding or usable phishing link.

---

## Scenario 02 — The Missing Package

**Difficulty:** 1/5  
**Duration target:** 3 min  
**Primary skill:** Checking the true status of a delivery  
**Emotional trigger:** Convenience, minor payments, everyday impatience  
**UI assets:** SMS, parcel tracking, purchase receipt, mock payment sheet

### Opening scene

A player is expecting new headphones. A text arrives:

> **Courier Notice:** We couldn't deliver your package. Pay a small $1.20 rescheduling fee to avoid return to sender. `parcel-help.example.com`

A package icon, shipping reference, and deadline make the message feel routine.

### Playable beats and decisions

**Beat A — What do you believe?**

- **A.** Pay the small fee. → A mock checkout requests a full card number; a tiny fee can be a pretext for obtaining sensitive information.
- **B.** Open the original order confirmation. → The actual tracking number is different from the SMS reference.
- **C.** Ask the sender for a photo. → A generic delivery photo arrives; it does not establish that the sender controls the parcel.
- **D.** Throw away the notification. → Nothing is compromised, but the player hasn't checked the real order.

**Beat B — Cross-check:** Open the merchant's order page or courier app **from the original order**. It says “Out for delivery, no additional fee.” If the player has already opened the fake form, they can back out before submitting sensitive information.

### Endings

- **Best:** Compare the original order and tracking record; avoid the unverified payment request. **3 shields.**
- **Mixed:** Close the message without checking the order. **1–2 shields.**
- **Risky:** Submit card details to the imitation checkout. The game shows a simulated fraud alert and introduces immediate card-reporting steps. **0–1 shields.**

### Debrief reveal

> “The suspicious part wasn't the amount. It was asking you to leave your trusted purchase flow and enter payment details somewhere new.”

**Transferable habit:** Track orders through the original merchant or carrier, not a link in an unexpected text.

**Replay twist:** The delivery really is delayed, but the official order page shows a legitimate rescheduling process. The point is to choose the **right channel**, not to assume delays are fake.

**Implementation notes:** Reuse the SMS, mock web view, and receipt components from Scenario 01.

---

## Scenario 03 — The Marketplace Buyer

**Difficulty:** 2/5  
**Duration target:** 4 min  
**Primary skill:** Distinguishing screenshots from verified payments  
**Emotional trigger:** Excitement about a quick sale; social pressure  
**UI assets:** Marketplace chat, listing, mock payment notification, banking ledger

### Opening scene

The player lists a second-hand bicycle for $150. Within minutes, a friendly buyer appears:

> **Maya:** I love it! This is exactly the one my brother wants. Can my courier pick it up today?
>
> **Maya:** I've already transferred the money. Here's the receipt. The courier is outside—can you hand over the bike?

A realistic-looking receipt image appears showing “PAYMENT SUCCESSFUL — $150.”

### Playable beats and decisions

**Beat A — Release the bicycle?**

- **A.** Give it to the courier because the receipt says “successful.” → The bike leaves; the player's own ledger still has no incoming transfer.
- **B.** Check the account balance and transaction history directly. → No completed payment appears.
- **C.** Ask the buyer to promise the payment is real. → The buyer insists and adds guilt: “Please, you're wasting my driver's time.”
- **D.** Cancel the sale immediately. → Safe, but may be unnecessary if the buyer can complete a verified payment.

**Beat B — Negotiate a safe next step:** Tell the buyer the item can be handed over once the seller's payment provider confirms the funds are received and usable. The buyer may wait, choose a permitted cash transaction, or disappear.

### Endings

- **Best:** Check the seller's own payment account; release the item only after verified payment. **3 shields.**
- **Mixed:** Cancel without any verification. **2 shields.**
- **Risky:** Trust the screenshot and lose the fictional bicycle. A follow-up recovery decision offers reporting and preservation of chat records. **0–1 shields.**

### Debrief reveal

> “A screenshot is a claim about payment, not payment itself. Verify receipt in the service that actually holds your funds.”

**Transferable habit:** A buyer's urgency does not replace your payment confirmation. Follow marketplace safety rules and avoid external payment or verification pages.

**Replay twist:** The buyer is honest, but payment is still pending. Safe boundaries preserve the sale once it genuinely clears.

**Implementation notes:** Reuse generic chat, payment ledger, and fake image-attachment cards. Do not teach how to forge receipts.

---

## Scenario 04 — The Perfect Job

**Difficulty:** 2/5  
**Duration target:** 4–5 min  
**Primary skill:** Recognizing a job/task scam that begins with positive reinforcement  
**Emotional trigger:** Hope, financial opportunity, sunk-cost pressure  
**UI assets:** Job listing, recruiter chat, simulated earnings dashboard, company site

### Opening scene

A remote job ad promises flexible hours for students and anyone needing extra income:

> **Recruiter:** No experience needed. Complete simple product-review tasks whenever you want. You could earn $80 a day.

The player completes a tutorial task and receives a small **fictional** $5 reward into an in-game balance. Then a new request appears:

> **Recruiter:** Great work! To unlock premium tasks and withdraw your earnings, deposit $45 into your training wallet. You get it all back after the next task.

### Playable beats and decisions

**Beat A — Assess the offer:**

- **A.** Deposit $45: “I already earned $5, so it's probably real.” → The in-game dashboard adds a large fictional reward, then demands a second deposit to withdraw it.
- **B.** Ask for a formal employment contract and independently verify the company. → The alleged employer's official careers page has no such listing.
- **C.** Ask for more screenshots of successful workers. → The recruiter sends testimonials, but these are not independent proof.
- **D.** Ignore everything without investigating. → Safe, but the player misses why the initial $5 was persuasive.

**Beat B — The sunk-cost moment:** After an initial simulated deposit on the risky branch, the game offers a chance to stop, preserve records, and report the suspected scam—rather than chase losses.

### Endings

- **Best:** Independently verify the employer and refuse pay-to-work/pay-to-withdraw requests. **3 shields.**
- **Recovery:** Stop immediately after the first fictional deposit, avoiding a larger loss. **1–2 shields.**
- **Risky:** Continue depositing to “unlock” money; the balance becomes inaccessible. **0 shields.**

### Debrief reveal

> “Some scams pay a little at first so they can ask for much more later. The first reward is part of the story—not proof that the job is legitimate.”

**Transferable habit:** Be highly suspicious of jobs requiring deposits or payments to withdraw wages. Independently confirm the employer and recruitment channel.

**Replay twist:** A legitimate job with a clear contract, real interviews, and no deposit requirement appears as a comparison.

**Implementation notes:** This scenario introduces the fictional wallet and delayed-consequence UI.

---

## Scenario 05 — The QR Code on the Wall

**Difficulty:** 2/5  
**Duration target:** 3–4 min  
**Primary skill:** Validating QR destinations before entering information  
**Emotional trigger:** Convenience and avoiding a parking penalty  
**UI assets:** Illustrated parking sign, QR scanner simulation, URL preview, official payment app

### Opening scene

The player parks near a crowded clinic. A sign says:

> **PAY PARKING NOW**  
> Scan the QR code to avoid a penalty.

The code looks professionally printed. An inspection reveals a newer sticker placed over an older printed code.

### Playable beats and decisions

**Beat A — How to pay?**

- **A.** Scan, trust the landing page, and enter card details. → The page asks for more information than a typical parking payment.
- **B.** Preview the QR's destination and compare it with the operator's independently listed website. → The domains differ.
- **C.** Pay another stranger to help you. → They are uncertain too; outsourcing a decision isn't verification.
- **D.** Leave without paying. → May avoid the fake site, but doesn't resolve a real parking obligation.

**Beat B — Safe resolution:** Use the parking operator's official app, a known payment machine, or verified staff instructions. The player pays the legitimate virtual parking charge if due.

### Endings

- **Best:** Recognize the altered sticker and pay through a verified channel. **3 shields.**
- **Mixed:** Avoid scanning but leave a genuine charge unresolved. **1–2 shields.**
- **Risky:** Enter details on the unverified destination. **0–1 shields**, with follow-up card-safety recovery.

### Debrief reveal

> “A QR code hides its destination. The physical sign around it can look authentic even if someone has changed where it sends you.”

**Transferable habit:** Inspect QR destinations; independently locate trusted payment channels for money or account logins.

**Replay twist:** The sticker is a harmless maintenance replacement. The verified destination matches the operator's independently listed domain; don't equate ‘unusual’ with ‘fraudulent.’

**Implementation notes:** The QR is fictional and never links to a live site. Reuse the same embedded browser and payment UI.

---

# Chapter II — The Human Factor

## Scenario 06 — The Voice That Sounds Like Home

**Difficulty:** 3/5  
**Duration target:** 4–5 min  
**Primary skill:** Verifying an urgent request when the voice sounds familiar  
**Emotional trigger:** Fear for a loved one's safety  
**UI assets:** Incoming-call screen, audio waveform with subtitles, contacts, family group chat

### Opening scene

An incoming call shows an unfamiliar number. The voice sounds exactly like the player's older brother, Sam:

> **“Sam”:** Hey, please don't panic. I got into an accident. I'm okay, but I need you to send $300 immediately to sort out the paperwork. My phone broke. Please don't call Mom—she'll panic.

The voice includes his familiar laugh and nickname for the player. The caller sounds frightened and rushed.

**Accessibility:** The same emotional cues are conveyed in text for users who cannot or do not want to listen to audio.

### Playable beats and decisions

**Beat A — Under pressure:**

- **A.** Send the money because the voice is recognizable. → A fictional transfer succeeds, but the number is not linked to Sam's verified account.
- **B.** Call Sam using the saved number already in Contacts. → Sam answers from home, safe and confused.
- **C.** Ask the caller for something only Sam might know. → The caller knows one detail from a public family post, reminding players that trivia is weak authentication.
- **D.** Hang up instantly. → Limits exposure, but leaves the alleged emergency unverified.

**Beat B — What if Sam doesn't answer?** A secondary branch simulates voicemail from the saved number. The best path is to use another known family contact or previously agreed safe process, and decline a pressured transfer until the claim is verified. The game never suggests ignoring a credible real emergency: if immediate safety is at stake, the player may contact appropriate emergency services.

### Endings

- **Best:** Independently call a saved number or a trusted family member and establish what is happening before transferring money. **3 shields.**
- **Mixed:** Refuse the transfer but never check whether help is genuinely needed. **1–2 shields.**
- **Risky:** Transfer to the unfamiliar account. The simulated aftermath reveals voice impersonation and offers reporting/recovery decisions. **0–1 shields.**

### Debrief reveal

> “A familiar voice is no longer enough to prove who is calling. You can care about the person and still verify the request.”

**Transferable habit:** Return calls using known numbers; establish a family verification habit in advance. A secret phrase can help, but should not be the only safeguard if it could have leaked.

**Replay twist:** On replay, Sam genuinely needs assistance; the successful route verifies the emergency first and then helps through an appropriate, trusted method. This directly counters the lesson that all urgent requests are scams.

**Implementation notes:** Ship text-only dialogue first. Optional original voice acting can be added later; no cloned real person's voice or required speech generation in the MVP.

---

## Scenario 07 — The Person Who Understands You

**Difficulty:** 3/5  
**Duration target:** 5 min  
**Primary skill:** Maintaining boundaries when a trusted online relationship introduces financial pressure  
**Emotional trigger:** Attachment, empathy, fear of hurting someone  
**UI assets:** Messaging timeline, profile photos using fictional artwork, video-call history, money-request panel

### Opening scene

A short montage compresses three weeks of friendly conversations with Alex, a person the player met in a language-exchange community. Alex remembers details, shares favorite books, and appears supportive during a difficult week.

Then a new message arrives:

> **Alex:** I hate asking. My flight got cancelled and I need $420 for another ticket. I can pay it back next week. You're the only person I trust right now. Please keep this between us.

The game deliberately avoids mocking the player for feeling attached.

### Playable beats and decisions

**Beat A — Answer the request:**

- **A.** Send the money to prove that the relationship is real. → Alex becomes more affectionate, followed by another emergency later.
- **B.** Respond kindly but set a clear financial boundary: “I'm sorry you're dealing with this, but I can't send money. Could you contact the airline directly?” → Alex starts pressuring the player and avoids practical alternatives.
- **C.** Demand a video call as absolute proof. → A live call may help establish some context, but it does not independently prove identity, intentions, or the financial claim.
- **D.** Publicly accuse Alex of fraud. → Escalates the situation without evidence and risks harming someone who may be genuine.

**Beat B — Read the pattern:** The player inspects older messages and sees a pattern of secrecy, isolation, escalating urgency, and avoidance of independent help. The player can preserve records, disengage, and report suspicious behavior through the platform.

### Endings

- **Best:** Show empathy while declining the pressured transfer; recognize the pattern and set boundaries. **3 shields.**
- **Mixed:** Stop responding without reviewing the pattern. **2 shields.**
- **Risky:** Send the money; future requests follow. A recovery path rewards stopping rather than chasing reimbursement through more payments. **0–1 shields.**

### Debrief reveal

> “Trust can grow naturally, and manipulation can imitate that process. You don't owe someone money to prove that you care.”

**Transferable habit:** Treat secrecy, rushed transfers, and emotional pressure as reasons to verify and set boundaries, not as proof of intimacy.

**Replay twist:** A genuinely distressed friend accepts a boundary and seeks appropriate assistance. The game rewards respectful skepticism, not humiliation or paranoia.

**Implementation notes:** Use a pre-authored chat montage rather than a simulated dating service; avoid real names/photos and stereotyping any nationality or demographic.

---

## Scenario 08 — Your Computer Is Infected!

**Difficulty:** 3/5  
**Duration target:** 4 min  
**Primary skill:** Differentiating a scare page from trusted device support  
**Emotional trigger:** Panic about losing files, fear of making things worse  
**UI assets:** Mock web browser, modal warning, system settings, installed-app list

### Opening scene

While researching a recipe, the player encounters a full-screen page with flashing borders:

> **CRITICAL SECURITY WARNING**  
> Your device is infected. Your photos may be deleted. Call our certified technician immediately or install the repair tool below.

An animated countdown starts. It looks like an operating-system alert, but it is inside a browser tab.

### Playable beats and decisions

**Beat A — React to the scare:**

- **A.** Call the listed “support number.” → A fictional agent pressures the player to give remote access to the device.
- **B.** Close the tab and open the device's actual security/update settings. → There is no corresponding operating-system alert.
- **C.** Install the “instant repair” app. → The simulated permissions screen asks for broad access unrelated to the claimed fix.
- **D.** Ignore every warning forever. → Wrong general habit: genuine operating-system alerts and updates may need attention.

**Beat B — Verify without escalating:** The player checks whether the message came from the browser or the actual OS, reviews installed software, and uses trusted system tools or an independently located official support channel.

### Endings

- **Best:** Identify the page as an untrusted web alert; avoid the support number/download; check through device settings. **3 shields.**
- **Recovery:** If the player installed the mock app, they can remove it, review permissions, and seek trusted help. **1–2 shields.**
- **Risky:** Grant remote access through the false technician prompt. Fictional files become exposed, followed by a guided recovery scene. **0–1 shields.**

### Debrief reveal

> “A webpage can pretend to be your operating system. Where a warning comes from matters more than how dramatic it looks.”

**Transferable habit:** Do not trust unsolicited “repair now” prompts. Use built-in settings and independently verified support routes.

**Replay twist:** A genuine system update appears in the OS settings; acting on it is the safe choice.

**Implementation notes:** Simulate everything in Unity; never request actual device permissions or use real remote-support software.

---

## Scenario 09 — The Scholarship You Didn't Apply For

**Difficulty:** 3/5  
**Duration target:** 4 min  
**Primary skill:** Validating institutional authority and requests for sensitive data  
**Emotional trigger:** Opportunity, gratitude, fear of missing out  
**UI assets:** Email, fictional school portal, document preview, contact directory

### Opening scene

A student receives an official-looking email:

> **Student Success Office:** Congratulations! You have been selected for a $2,000 emergency scholarship. To secure your award today, complete our identity review and pay the $18 verification charge.

The email includes a school crest, a formal signature, and the player's first name. A friend in the fictional campus group chat says, “I think I got one too.”

### Playable beats and decisions

**Beat A — Is it real?**

- **A.** Pay $18 immediately because the award is worth far more. → A second page requests an ID photo and student-portal password.
- **B.** Open the school portal from the existing bookmark and check scholarship announcements. → No such award exists, and the school lists known impersonation attempts.
- **C.** Reply to the sender asking for verification. → The same sender produces a professional-looking explanation.
- **D.** Post the email publicly and ask everyone to click it. → Increases potential exposure of other students.

**Beat B — Contact the school:** The player finds the student-aid office via the established school directory. A staff member confirms the scheme and explains how real aid applications work at that institution.

### Endings

- **Best:** Check official portal and independently contact student aid; avoid payment and disclosure. **3 shields.**
- **Mixed:** Delete the message without reporting it. **1–2 shields.**
- **Risky:** Enter simulated personal data on an unverified site. The aftermath explains identity-exposure steps. **0–1 shields.**

### Debrief reveal

> “Logos, signatures, and personal details are not the same as institutional proof. An award isn't real just because the message makes you feel chosen.”

**Transferable habit:** Verify grants, scholarships, and official documents using the real institution's portal or known contact details. Treat upfront verification fees as a serious warning sign.

**Replay twist:** A legitimate scholarship exists, but it is announced inside the school's verified portal with a consistent application process.

**Implementation notes:** Fictional institution and crest only; localize scholarship details to different countries and education systems.

---

## Scenario 10 — Everyone Is Getting Rich

**Difficulty:** 3/5  
**Duration target:** 5 min  
**Primary skill:** Evaluating investment claims, social proof, and withdrawal barriers  
**Emotional trigger:** FOMO, ambition, social comparison  
**UI assets:** Social feed, group chat, simulated portfolio chart, investment offer page

### Opening scene

A popular creator posts:

> **“I turned $300 into $3,000 in two weeks. My community has the strategy—only 20 spots remain.”**

Inside the group, members share exciting screenshots and praise the organizer. A simulated dashboard shows rising gains. The player is offered an “exclusive” investment opportunity promising a guaranteed weekly return.

### Playable beats and decisions

**Beat A — Follow the crowd?**

- **A.** Invest immediately because the chart only goes up. → The virtual dashboard shows profits, but withdrawal is blocked pending a “release tax.”
- **B.** Request verifiable company details, licensing/registration where applicable, terms, risks, and an independent explanation of withdrawals. → The promoter dodges specifics and repeats the urgency.
- **C.** Trust the screenshots from group members. → The player learns that a testimonial alone doesn't verify custody of funds or actual returns.
- **D.** Claim all investing is fraud. → Avoids this trap but fails the deeper lesson that legitimate investing exists and carries real risk.

**Beat B — The withdrawal test:** Players can inspect the fictional terms and compare the promoter's “guaranteed return” claims against standard risk disclosures. If they entered the risky path, they can refuse any additional payment to “unlock” proceeds.

### Endings

- **Best:** Recognize the unsupported guarantees, verify independently, and walk away from the specific offer. **3 shields.**
- **Recovery:** Stop after the initial fictional deposit instead of paying extra withdrawal fees. **1–2 shields.**
- **Risky:** Pay repeated fictional fees; the promised funds remain inaccessible. **0 shields.**

### Debrief reveal

> “A number on a dashboard is not money you can withdraw. Excitement and social proof are not substitutes for independent evidence.”

**Transferable habit:** Be skeptical of guaranteed high returns, urgency, and hidden withdrawal costs. Assess legitimacy and risk through independent sources. This level does not provide financial advice or endorse a specific asset.

**Replay twist:** A transparent, legitimate investment service discloses fees and downside risk rather than promising certain returns. The strongest player evaluates it thoughtfully instead of assuming all investments are identical.

**Implementation notes:** No real trading, tokens, money transfer, platform recommendation, or specific expected returns. Charts and balances are obviously fictional in-game simulations.

---

# Chapter III — The Bigger Picture

## Scenario 11 — The Video Everyone Is Sharing

**Difficulty:** 4/5  
**Duration target:** 4–5 min  
**Primary skill:** Avoiding impulsive sharing of potentially manipulated or context-free media  
**Emotional trigger:** Anger, belonging, desire to help  
**UI assets:** Social feed, short fictional video/stills, source cards, article timeline

### Opening scene

A dramatic, 12-second fictional video appears in the player's feed. It seems to show a school principal saying, “Students who can't pay fees don't deserve to graduate.” Comments explode with outrage.

> **Friend:** This is disgusting. We need to repost it before they delete the evidence.

The clip is convincing, and the story is emotionally urgent. The game does not initially say whether it is AI-generated, clipped out of context, or genuine.

### Playable beats and decisions

**Beat A — Will you share?**

- **A.** Repost the clip immediately with an angry caption. → A fictional rumor spreads through the campus feed; later evidence contradicts the claim.
- **B.** Inspect the original upload date, source, and longer recording. → The clip was cut from a simulated exercise in which the principal was quoting a discriminatory comment to criticize it.
- **C.** Decide it must be AI-generated because the lip movement looks odd. → That is not a reliable conclusion; compression and editing also create visual artifacts.
- **D.** Assume no online video can be trusted. → Avoids this repost but blocks useful, well-sourced information too.

**Beat B — Handle uncertainty:** Players compare two independent contextual sources and choose whether to publish, wait, or share a carefully qualified correction. A “source trail” mechanic teaches lateral reading.

### Endings

- **Best:** Check original context and independent reporting; avoid spreading an unsupported interpretation. **3 shields.**
- **Recovery:** Repost initially, then remove or correct it promptly after learning the context. **1–2 shields.**
- **Risky:** Amplify the false accusation, dismiss corrective evidence, and create a fictional reputation crisis. **0 shields.**

### Debrief reveal

> “A video can be real while the story attached to it is false. Before you share a claim, check where it came from and what happened before and after the clip.”

**Transferable habit:** Trace media to its source, seek surrounding context, and look for independent corroboration. Don't label media fake solely from a visual hunch.

**Replay twist:** A genuinely troubling event is independently corroborated. The correct response becomes sharing responsibly with proper context instead of dismissing it.

**Implementation notes:** MVP can use illustrated storyboards, subtitles, and still frames; actual generated video is not necessary. Avoid real political figures, current controversies, or defamatory likenesses.

---

## Scenario 12 — Help After the Flood

**Difficulty:** 4/5  
**Duration target:** 4 min  
**Primary skill:** Donating safely while preserving empathy  
**Emotional trigger:** Compassion, urgency, guilt  
**UI assets:** Disaster news mock, charity post, organization directory, virtual donation confirmation

### Opening scene

A major flood has displaced families in a fictional region. A post shows a distressed child and says:

> **EMERGENCY RELIEF:** We need supplies before midnight. Send help directly to our temporary account. Do not delay with paperwork—children are waiting.

A familiar classmate has reshared it, adding: “Please do something.”

### Playable beats and decisions

**Beat A — How should you help?**

- **A.** Donate immediately through the post's payment details. → The destination belongs to an unverified intermediary; there is no credible explanation of where the donation goes.
- **B.** Find the charity through independently verified contact information and published donation channels. → A real relief campaign exists, but with different account details.
- **C.** Refuse to help anyone online. → Keeps the player away from this trap but unnecessarily rejects legitimate aid.
- **D.** Share the post without donating. → Amplifies an unverified payment request and can expose friends.

**Beat B — Respond constructively:** The player can donate fictional funds through the verified campaign, share an official link, or volunteer through an established organization. Optional response to the classmate: “I found the verified donation page; let's share that instead.”

### Endings

- **Best:** Verify the organization, help through an authentic channel, and respectfully correct the risky share. **3 shields.**
- **Mixed:** Avoid the suspicious link but do not follow through on a desired donation. **1–2 shields.**
- **Risky:** Send fictional funds to the unverified destination and circulate the post further. **0–1 shields.**

### Debrief reveal

> “Compassion deserves a safe path. Checking where money goes doesn't make you less caring—it can make your help more effective.”

**Transferable habit:** For crisis donations, use official sites and independently verified organizations. Treat urgency as a reason to act carefully, not impulsively.

**Replay twist:** A smaller community fundraiser is genuinely legitimate but has limited public information. The player can ask for transparent organizers and accountable payment methods without automatically accusing anyone.

**Implementation notes:** Use fictional disasters and artwork; do not use exploitative imagery of real victims.

---

## Scenario 13 — The Free Photo Editor

**Difficulty:** 4/5  
**Duration target:** 4 min  
**Primary skill:** Understanding app permissions and privacy tradeoffs  
**Emotional trigger:** Desire for a fun free tool; convenience  
**UI assets:** Fictional app-store listing, system-like permission dialogs, privacy panel, before/after photo tool

### Opening scene

A photo-editing app is trending in the fictional app store. It promises “cinematic portraits in one tap.” The player taps Install, and a series of permission requests appears:

> **PhotoMagic wants access to:** Contacts, precise location, microphone, and all photos.

The app explains: “Enable everything for the best experience.”

### Playable beats and decisions

**Beat A — Give access?**

- **A.** Allow every permission to get the effect faster. → A summary shows the app can access information unrelated to basic photo editing.
- **B.** Grant access only to a selected photo and deny unrelated permissions. → The app's core edit feature still works in this fictional version.
- **C.** Assume every permission request is malicious. → Overgeneralizes: a camera app may reasonably need camera access, for example.
- **D.** Ignore permission dialogs because the store already approved the app. → Misses the player's role in limiting data access.

**Beat B — Evaluate the app:** Inspect developer identity, privacy information, reviews with reasonable skepticism, and feature necessity. The player can keep the app with limited access, choose an alternative, or uninstall it.

### Endings

- **Best:** Assess the app's actual needs and choose the minimum practical permissions. **3 shields.**
- **Mixed:** Uninstall immediately with no assessment. **1–2 shields.**
- **Risky:** Grant broad unnecessary access; a fictional privacy report illustrates what was exposed. **0–1 shields.**

### Debrief reveal

> “A free app may still have a data cost. Permission requests should match the feature you're trying to use.”

**Transferable habit:** Use selective photo access and minimize unnecessary permissions. Review permission settings periodically. A permission's appropriateness depends on the feature and platform.

**Replay twist:** The user opts into a voice-caption feature; microphone permission becomes relevant *only while recording*. The player must judge context rather than memorizing “microphone = bad.”

**Implementation notes:** Permission screens must be explicitly styled as **in-game simulations**. The game itself should request minimal real device permissions.

---

## Scenario 14 — A Message from the CEO

**Difficulty:** 4/5  
**Duration target:** 5–6 min  
**Primary skill:** Independently verifying changes to financial instructions at work  
**Emotional trigger:** Authority, workplace loyalty, fear of disappointing a superior  
**UI assets:** Corporate email mock, invoice, vendor ledger, internal contacts, approval workflow

### Opening scene

The player is helping manage a small nonprofit's payments. At 4:45 p.m., the director appears to email:

> **Subject:** Urgent — Vendor Bank Details Updated  
> We need to pay the event supplier today. They've changed banks. The revised account is attached. I'm boarding a flight, so please handle this quietly and don't slow it down with another approval meeting.

The email signature matches past messages. The invoice number and project name are real details already visible in the simulated office workspace.

### Playable beats and decisions

**Beat A — Execute the change?**

- **A.** Update the payment account because the director requested it. → The fictional transfer goes to an unverified account; later the legitimate vendor denies changing banks.
- **B.** Contact the vendor using the phone number in the pre-existing vendor directory, and follow the organization's approval process. → The vendor confirms that no bank change was requested.
- **C.** Reply to the email to ask whether it is genuine. → The same potentially compromised channel replies “Yes, hurry.”
- **D.** Refuse to pay any vendor ever again. → Prevents this loss but fails the realistic job responsibility.

**Beat B — Pushback from authority:** A simulated “director” message says, “I explicitly told you not to call.” Players must decide whether to uphold the verification policy despite social discomfort. The actual director later thanks them for checking.

### Endings

- **Best:** Use the established vendor contact and dual-approval controls; report the suspicious change. **3 shields.**
- **Mixed:** Delay payment without investigating or informing the team. **1–2 shields.**
- **Risky:** Send the transfer; the mock finance team discovers the redirection. Recovery focuses on immediate notification and evidence preservation. **0–1 shields.**

### Debrief reveal

> “Authority and familiarity make a request feel safe. But changing the destination for money demands a second, independent verification step.”

**Transferable habit:** Confirm sensitive payment changes through trusted contact details already on file and follow organizational procedures, regardless of who appears to request them.

**Replay twist:** The vendor's bank details really have changed. Independent callback and normal approvals allow the correct payment to happen safely.

**Implementation notes:** One re-usable email view, one vendor contact card, one mock approval state machine; avoid real corporate identities or actionable fraud templates.

---

## Scenario 15 — The Chain Reaction (MVP Finale)

**Difficulty:** 5/5  
**Duration target:** 6–7 min  
**Primary skill:** Applying multiple verification habits when signals conflict  
**Emotional trigger:** Friendship, urgency, distraction, desire to do the right thing  
**UI assets:** Combined messages, mock authenticator notification, social feed, contacts, account security page, phone call

### Opening scene

The player is finishing dinner. Three notifications arrive almost simultaneously:

1. **Friend message — Jordan:** “Hey! I entered a contest. Can you vote for me? I only need one more vote to win.”
2. **Account notification:** “New sign-in attempt. If this wasn't you, review security activity.”
3. **Jordan again:** “The voting site sent a code to your phone because I used your number by mistake. Can you tell me the code? I'm panicking.”

The contest link looks ordinary and Jordan's messages resemble their usual writing style. The player must determine which events are connected without jumping to conclusions.

### Playable beats and decisions

**Beat A — The code request:**

- **A.** Give Jordan the verification code to help. → In the simulation, the code was actually for the player's own account; an unauthorized session becomes active.
- **B.** Open account-security settings through the trusted app and examine the login event. → The new sign-in attempt is unrelated to voting and was not requested by the player.
- **C.** Ask Jordan inside the same chat whether they're really Jordan. → The reply says yes, but the chat itself may be compromised.
- **D.** Ignore everything. → Avoids sharing the code, but does not address the suspicious sign-in attempt.

**Beat B — Verify the friendship:** Use the known number saved for Jordan, or a separately trusted communication channel. Jordan answers and says their social account was taken over earlier that evening. They never entered a contest.

**Beat C — Contain and support:** The player rejects the unauthorized sign-in, secures the account from inside the real app, reviews active sessions, and tells Jordan to follow the platform's account-recovery process. The player can warn mutual friends **without sharing private evidence publicly**.

### Three meaningful finales

- **Best — The Protector (3 shields):** Never share the code, independently confirm Jordan's identity, secure the account, and share a calm warning with friends.
- **Recovery — The Second Chance (1–2 shields):** Share the code initially, notice the unusual sign-in, then immediately revoke sessions and follow the recovery flow. The fictional harm is limited. This reinforces that stopping early still matters.
- **Risky — The Domino Effect (0 shields):** Share the code, approve an unfamiliar login, and forward the contest request. The simulated attacker reaches more contacts. The final replay reveals the exact chain of decisions that made it possible.

### Debrief reveal

> “The attacker didn't need you to be careless. They needed you to be helpful, rushed, and distracted—all at once. Your strongest skill is knowing how to verify, even when a request comes from someone you trust.”

**Transferable habit:** Never provide login/verification codes to another person. Treat unexpected account alerts seriously using the real app. Verify unusual requests from friends by a separate route, and support victims without shaming them.

### Closing scene

The next morning Jordan sends a message from their recovered account:

> **Jordan:** “Thanks for checking before trusting that message. You didn't just protect your account. You helped me protect everyone else too.”

The player receives **THE TRUST INSTINCT** badge and sees their personal learning journey—not a claim that they are now “scam-proof.”

A final card reads:

> **You can't control every message you receive. You can control what happens next.**

**Replay twist:** Another run includes a legitimate account sign-in made by the player on a second device and a real request from Jordan. Strong decisions require evaluating both events separately.

**Implementation notes:** This finale recombines earlier UI components and mechanics, making it a systemic challenge rather than a new content-heavy minigame. All codes, logins, and sessions are simulated; the game never asks for an actual OTP.

---

# Part III — Why People Might Love This Game

## 1. The Core Emotional Insight

Most people do not wake up wanting to study cybersecurity. They do wake up wanting to protect their money, their loved ones, their privacy, and their reputation.

That is where TRUST begins.

The player doesn't open a textbook. They see a bank warning, a friend who needs help, an exciting offer, or a video everyone is discussing. They feel something familiar: urgency, guilt, hope, curiosity, fear, or loyalty. They act. The world responds. Then they discover the one small habit that could change the outcome.

**The entertainment is the decision under pressure. The education is the insight after the reveal.**

TRUST should feel like a series of tiny interactive mysteries with human stakes. Each episode offers a question the player wants answered: *Is this genuine? What am I missing? How can I help without being manipulated?*

## 2. Six Reasons the Concept Could Connect with a Wide Audience

### Reason 1 — Nearly everyone recognizes the situation

You don't need to understand fantasy lore, combat systems, or complicated controls. A surprising message or a suspicious payment request is immediately understandable. Familiar situations create a low barrier to entry.

**Design implication:** The first screen must begin with a realistic notification, not an explanation of cybersecurity terminology.

### Reason 2 — The player becomes the hero through judgment

Many games celebrate physical strength, speed, or luck. TRUST celebrates noticing, questioning, and helping. The victory is not defeating a villain in combat; it is protecting someone at the moment it matters.

**Design implication:** Reward thoughtful action, not only perfect answers. A player who makes a mistake and recovers should still feel capable.

### Reason 3 — Every level has a short story with a reveal

The best scenarios contain uncertainty and a twist. A suspicious warning might turn out to be legitimate. A trusted friend might have a compromised account. A heartfelt donation appeal might lead to the wrong payment destination.

**Design implication:** Vary the outcome. If every unfamiliar message is fake, players will memorize the pattern and stop thinking.

### Reason 4 — Players can talk about it without spoilers

A player might ask a parent, friend, or colleague: “If your brother called crying and asked for money from an unknown number, what would you do?” The situation is a conversation starter even outside the app.

**Design implication:** Provide optional, spoiler-free challenge cards. Do not auto-share choices, mistakes, contacts, or personal security information.

### Reason 5 — It can generate meaningful progress

A typical game badge says “You cleared Level 10.” TRUST can also say “You practiced verifying a caller,” “You spotted a fake payment confirmation,” or “You learned to recover after a mistake.”

**Design implication:** Display earned skills, not exaggerated claims of real-world protection. Celebrate progress without declaring the user invulnerable.

### Reason 6 — It's useful enough to recommend to someone you love

A game that is entertaining *and* may help someone avoid a harmful decision gives players an unusually personal reason to recommend it: “Try this; I think it could help you.”

**Design implication:** Make the first three episodes enjoyable, fully playable, and easy to understand without an account, payment, or intrusive onboarding.

## 3. The Critical Differentiator

| Ordinary cybersecurity training | TRUST |
|---|---|
| “Here are five warning signs.” | “Your brother is calling for help. What do you do?” |
| Explains danger before the quiz | Creates a safe mystery, then reveals the danger |
| Focuses on remembering facts | Practices independent verification under pressure |
| One right answer, one wrong answer | Several plausible routes and recoverable consequences |
| Rewards only perfect choices | Rewards investigation, proportionate action, and recovery |
| Often stops at individual knowledge | Gives players language to help friends and family |

**Positioning statement:**

> **TRUST is a playable survival guide for the digital world: short, dramatic stories that turn uncertain online moments into confidence-building decisions.**

---

# Part IV — Ready-to-Use Persuasive Pitches

## Pitch A — One-Sentence Hook

> **What if five minutes of playing a game today could help you recognize the message that might cost you your savings tomorrow?**

Use this for a landing-page hero, social profile, or presentation opening. This is a possibility statement, not a proven outcome claim.

## Pitch B — 30-Second Elevator Pitch

> We teach people how to cross a street before they walk through traffic. But we give them access to banking, social media, online shopping, and AI-powered communication without giving them a safe place to practice the dangers.
>
> TRUST changes that. It's a free mobile game where you experience realistic digital dilemmas: a suspicious bank alert, an urgent call from a loved one, a fake job offer, or a viral video that might be misleading.
>
> Every decision changes the story. Every mistake becomes a lesson. And every lesson is a skill you can use tomorrow.
>
> **It's not a lecture about the digital world. It's a game that helps you navigate it.**

## Pitch C — 90-Second Emotional Pitch

> Imagine you're having dinner when your phone rings.
>
> It's your brother's voice. He sounds terrified. He says he's been in an accident, his phone is broken, and he needs money immediately. He asks you not to tell your parents.
>
> What would you do?
>
> Most games ask you to fight monsters. TRUST asks you to face something far more familiar: uncertainty, pressure, and the feeling that someone you care about needs you.
>
> In TRUST, you can make the wrong choice. You can trust the convincing voice. You can send the fictional money. You can watch the consequences unfold.
>
> But unlike real life, you get to understand the mistake in a safe environment. You can replay the scene, discover the clues you missed, and practice a better response: calling your brother using a number you already know, checking with another family member, and acting from verified information rather than panic.
>
> That's one level. Other levels explore online shopping, jobs, scams, fake videos, charity appeals, privacy, and account security. Every scenario is a short interactive story. Every story builds an instinct.
>
> We believe people won't return because the app tells them to study. They'll return because the stories are surprising, the choices feel real, and each victory makes them feel more capable.
>
> Our goal is ambitious: make practical digital literacy as accessible, engaging, and shareable as a great mobile game.
>
> **If TRUST succeeds, a game session won't end when the screen closes. It will change what a player does the next time their real phone rings.**

## Pitch D — For Players: App Store Description

### TRUST — Would You Fall for It?

**A message. A choice. A consequence.**

Your bank says something is wrong. A stranger offers you the perfect job. Your friend needs help urgently. A video goes viral—and everyone expects you to share it.

Can you spot what matters before it's too late?

In TRUST, every episode is a bite-sized interactive mystery inspired by real kinds of digital manipulation. Explore chats, inspect clues, question surprising claims, and discover how small decisions lead to big consequences.

**Play for the story. Stay for the confidence.**

- 15 story-driven challenges in the initial release
- Realistic decisions with multiple endings
- Mystery, tension, and surprising reveals
- Practical lessons you can share with friends and family
- No real money, banking logins, or sensitive personal information required
- Free core educational content

**Think before you tap. Verify before you trust.**

*Note: Game scenarios are fictional. TRUST helps people practice safety habits but cannot guarantee protection from real-world scams.*

## Pitch E — For Schools, Banks, and Nonprofits

> People often know that online scams exist, yet knowledge alone may not translate into safer behavior during a stressful moment. TRUST offers a different approach: safe, repeatable practice.
>
> Instead of assigning another long presentation, you can invite learners to experience short, realistic dilemmas. They inspect evidence, choose a response, see a consequence, and practice the next step.
>
> The product is designed to be accessible, localizable, and measurable through privacy-respecting learning assessments. Organizations can use it as a supplement to their existing educational programs, with reviewable scenarios and no need to collect learners' real passwords, payment details, or messages.
>
> **The proposition is simple: turn security awareness from information people hear into decisions they can practice.**

**What a pilot partner gets:** A defined set of reviewed scenarios; before/after challenge scores; opt-in, aggregated learning insights; localization support; and a way to measure improvement rather than assume it.

## Pitch F — For a Potential Investor or Co-Founder

> TRUST targets a persistent problem: people routinely make high-stakes digital decisions without an opportunity to practice them safely. Traditional security awareness content can be difficult to engage with, especially outside workplaces. Mobile games, meanwhile, excel at creating repetition, feedback, and emotional investment.
>
> TRUST combines those strengths in a lightweight, reusable narrative engine. The MVP needs no expensive 3D content, multiplayer infrastructure, or generative AI. Its core assets are scenario design, a reusable simulated-phone interface, branching outcomes, and a measurable learning loop.
>
> The initial go-to-market hypothesis is a free consumer product that can spread through word of mouth and referral challenges. A second hypothesis is institution-funded licensing for schools, banks, and nonprofits seeking practical digital-literacy tools.
>
> We are not assuming that educational value automatically creates retention, or that institutions will pay without evidence. The plan is to validate three things quickly: **Do people enjoy the stories? Do they come back? Do their verification decisions improve on new situations?**
>
> If these hypotheses hold, TRUST could evolve into a scalable library of localized, expert-reviewed digital safety simulations with both consumer and institutional distribution.
>
> **The business opportunity is to make safer digital behavior desirable to practice—not merely important to understand.**

## Pitch G — A 30-Second Trailer Script

**0–05s — Black screen, vibrating phone**  
On-screen text: *“Your brother is calling.”*

**05–10s — Call audio or subtitles**  
“I'm in trouble. Please send the money. Don't tell anyone.”

**10–15s — Player fingers hover over SEND**  
On-screen text: *“He sounds exactly like your brother.”*

**15–20s — Snap cut to another notification**  
*“New sign-in attempt detected.”*  
*“Your package will be returned.”*  
*“You've won a scholarship.”*

**20–25s — Quick scenes of clues being inspected**  
Voiceover: *“In the digital world, the hardest choices don't look like a game.”*

**25–30s — Logo and promise**  
**TRUST**  
*“The game that trains your instincts.”*  
**A message. A choice. A consequence.**

---

# Part V — Making It Truly Fun: Game Systems for the MVP

## 1. Story first, lesson second

Don't open a level with “Today you'll learn about phishing.” That reveals the trick and turns the experience into a test. Open with a human situation. Explain the specific concept only after the player has formed a hypothesis or made a decision.

## 2. Give every level at least one uncertainty

If a scenario has only “Click scam link” vs “Do not click scam link,” it is not a compelling game. A good scene includes believable evidence, emotional pressure, and a meaningful path to verification. Some stories should be genuinely legitimate to preserve uncertainty.

## 3. Use expressive consequences, not humiliating punishments

A wrong move should produce dramatic but safe fictional consequences. The interface can show a disappearing package, a dashboard becoming inaccessible, or an urgent follow-up from a friend. Never display “Only idiots fall for this.” The game must be particularly respectful toward people who have experienced real scams.

## 4. Add a short mystery reveal

After a decision, show **What you saw**, **What you assumed**, **What you could have checked**, and **What to try next time**. A short visual replay of one key clue is more memorable than a full page of generic advice.

## 5. Let players use their skills to help others

The finale should shift the player's identity from simply protecting themselves to supporting friends. Later releases might include fictional family conversations and helpful, non-shaming guidance. Avoid real-time scam reporting or case-specific legal advice in the MVP.

## 6. Make replay meaningful

Level replays can swap one pivotal fact: the alert is real, the friend is authentic, the donation link is verified, or the buyer's payment is merely delayed. This prevents players from winning through pattern memorization. For the MVP, author **one short twist per level**; no procedural AI is necessary.

## 7. Keep progression light

**MVP campaign map:** 3 chapters × 5 episodes. Unlock the next level upon finishing the current one, regardless of shields. A player who makes mistakes should never be locked out of learning.

**Collectibles:** 15 scenario badges, 3 chapter badges, and one finale badge. No gacha, stamina timers, pay-to-skip, daily streak punishments, or manipulative limited-time offers.

**Accessibility:** Large text option; captions; reduced-motion mode; high-contrast UI; screen-reader-friendly labels where platform integration allows; no mandatory real-time responses. Characters and examples must be culturally adaptable.

## 8. A small but compelling content cadence

For the initial launch, release the 15 scenarios as one self-contained season. Test demand for future seasons such as **Family & Relationships**, **Work & Money**, **AI & Misinformation**, and **Everyday Privacy**. Don't advertise a live service until there is a sustainable content pipeline.

---

# Part VI — MVP Production Blueprint

## Required screens and reusable components

| Component | Used in | MVP requirement |
|---|---|---|
| Episode map | All levels | Chapter progression, replay, skill badges |
| Message/chat screen | 01–04, 06–07, 09, 12, 15 | Bubbles, timestamps, profile identity, clickable evidence |
| Email view | 09, 14 | Sender details, attachments, thread context |
| Simulated browser | 01–02, 05, 08, 10–11 | Address preview, links, article/source cards |
| Transaction/wallet view | 01–04, 07, 10, 12, 14 | Fictional balances, incoming/pending status |
| Contact/call view | 06, 14–15 | Independent callback, call status, verified contacts |
| Social feed | 07, 10–12, 15 | Posts, comments, resharing choices |
| Device security/privacy | 08, 13, 15 | Permission prompts, sign-in alerts, account settings |
| Evidence inspect overlay | All levels | Discoverable clues and context without forcing linear taps |
| Decision panel | All levels | 2–4 thoughtful actions, no trivially good/bad wording |
| Outcome/reveal panel | All levels | Consequence, 3 shields, transfer habit, replay |
| Accessibility/settings | All levels | Font size, audio/caption, motion, language framework |

### Technical approach (Unity-focused)

- Build the MVP with **Unity UI Toolkit** if it meets target-device accessibility and text-input requirements; validate complex text/scrolling on devices early. The simulated phone is a set of views, not a 3D world.
- Keep story content in **external JSON or ScriptableObjects**. Do not hard-code level dialogue in 15 separate MonoBehaviours.
- Use a simple **scenario state machine**: `EnterNode -> ShowContent -> Inspect/Choose -> SetFlags -> Transition -> Resolve`.
- Reuse a small pool of **message, browser, document, call, and decision templates**; level files should define the dialogue, clues, conditions, and consequences.
- Store local player progress only as needed. No real bank credentials, contacts, browsing history, microphone recordings, or personal chats should be collected.
- Use a deterministic narrative engine for the MVP. Generative AI is an optional future authoring aid, not a required runtime dependency.
- Add localization keys from the beginning. Model amounts and institutions generically; prepare cultural adaptations rather than literal translations only.

### Minimal scenario data contract (illustrative)

```json
{
  "id": "S01_BANK_ALERT",
  "chapter": 1,
  "difficulty": 1,
  "startNode": "sms_received",
  "nodes": {
    "sms_received": {
      "view": "chat",
      "titleKey": "s01.title",
      "messageKeys": ["s01.sms1", "s01.sms2"],
      "clues": ["unknown_sender", "external_url", "deadline"],
      "choices": [
        {
          "id": "open_saved_app",
          "labelKey": "s01.choice.openApp",
          "nextNode": "bank_app",
          "flags": ["verified_channel_selected"]
        },
        {
          "id": "open_sms_link",
          "labelKey": "s01.choice.openLink",
          "nextNode": "untrusted_login_page",
          "flags": ["external_link_opened"]
        }
      ]
    }
  },
  "endings": ["best", "mixed", "risky"],
  "skills": ["independent_verification", "otp_safety"]
}
```

This is a small *conceptual* contract, not a production-complete schema. A real implementation needs validation, deterministic conditional branches, localization resolution, scoring rules, save/version migration, automated narrative-path tests, and accessible input/navigation.

## Scenario acceptance checklist

Every level should pass these tests before release:

- [ ] The fictional situation is understandable without technical background.
- [ ] There are at least two plausible actions; the optimal action isn't obvious from wording alone.
- [ ] At least one clue is discoverable through interaction.
- [ ] A verification route exists and is safe.
- [ ] A player can finish in a short session, with an option to replay.
- [ ] Wrong choices have fictional consequences but don't shame the player.
- [ ] If harm occurs, a realistic next-best recovery action is offered.
- [ ] The debrief teaches a generalizable principle, not a brittle rule.
- [ ] No genuine credentials, OTPs, sensitive contacts, or financial data are requested.
- [ ] Localization, readability, and accessibility have been checked.
- [ ] A domain expert reviews the scenario's security guidance before publication.

---

# Part VII — Proving It Works (Instead of Assuming Everyone Will Love It)

**The ambition is broad appeal. Universal appeal cannot honestly be promised.** A persuasive pitch is stronger when it explains why the concept *could* attract players and how the team will test that hypothesis.

## Three questions to validate

1. **Entertainment:** Do players want another episode after completing the first one?
2. **Learning transfer:** Can players make safer decisions on unfamiliar, *new* situations rather than only on scenarios they memorized?
3. **Organic recommendation:** Would they willingly recommend the experience to someone they care about?

## Suggested early pilot (targets, not actual results)

Recruit a diverse group of testers, including at least some people who are *not* gamers or developers. Avoid testing only with technically sophisticated friends. Use qualitative interviews as well as event telemetry.

| Metric | How to measure | Initial decision-use |
|---|---|---|
| First-level completion | Completed S01 ÷ started S01 | Is onboarding intuitive? |
| Chapter I completion | Completed S05 ÷ started S01 | Are early scenarios compelling? |
| Voluntary next-level rate | Players who choose another level after a reveal | Does the mystery/feedback loop create desire? |
| Scenario replay rate | Players who intentionally replay | Are alternate endings interesting? |
| Session duration | Median time per completed level | Does it match the 3–5 minute design target? |
| New-scenario transfer | Score on fresh, untrained scenarios before vs. after | Are decisions improving beyond memorization? |
| Helpful recommendation intent | Anonymous, voluntary survey | Would someone share it with family or friends? |
| Confusion and distress | Optional feedback + observed usability issues | Is pressure engaging without becoming harmful? |

**Example go/no-go criteria for a small pilot:** Define quantitative targets *before* collecting data, then revise based on pilot size, audience, and distribution. Do not fabricate benchmarks or call a pre/post improvement causal proof unless the study design supports it. Stronger evidence would include a comparison group, novel scenarios, and a later retention check.

### Five common product risks, and how to address them

| Risk | Mitigation |
|---|---|
| It feels like homework | Lead with story, mystery, and choices; keep lessons short |
| Players learn “always say no” | Include genuine alerts and legitimate requests in replay variants |
| The content becomes stale | Separate content from code; establish expert review and scenario updates |
| People feel ashamed after mistakes | Offer recovery paths, compassionate copy, and opt-out from stressful scenes |
| Institutions value it but gamers don't | Measure both consumer engagement and learning outcomes; adapt distribution honestly |

### Ethical product commitments

1. **Never monetize fear.** No ads inside frightening scam scenes, and no paywall before a safety lesson or recovery tip.
2. **Never collect actual secrets.** No real passwords, OTPs, bank details, private messages, or contact lists for gameplay.
3. **Never disguise simulation as a real system alert.** Clearly identify the fictional environment before gameplay and in sensitive interfaces.
4. **Respect vulnerabilities.** Users may have experienced financial abuse, coercion, or scams. Provide content notices and a way to skip without losing educational access.
5. **Make trustworthy claims.** Teach practical habits; don't claim that using the app guarantees financial safety or cybersecurity.

---

# Final Vision — The Experience People Remember

A great educational product doesn't succeed because its mission is admirable. It succeeds because the experience itself is worth returning to.

TRUST has the potential to make a forgotten category of learning feel personal. It doesn't require a player to care about abstract digital threats. It begins with something they already care about: a message from a friend, the safety of their family, the possibility of a better job, or the desire to help a stranger.

The player enters with uncertainty, makes a meaningful choice, sees what happens, and leaves with a stronger habit. Over 15 episodes, the experience changes from *“Can I spot a suspicious message?”* to *“Can I think clearly and help other people when the situation matters?”*

That's the emotional transformation the game should aim to deliver.

**The promise is not that everyone will love TRUST. The promise is that we're building something worth loving: a genuinely entertaining game that respects players' intelligence and gives them knowledge they can use outside the screen.**

> **TRUST — Play the story. Learn the instinct. Protect what matters.**
