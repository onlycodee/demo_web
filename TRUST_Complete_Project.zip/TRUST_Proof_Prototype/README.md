# TRUST — Working Narrative Engine Prototype

> An interactive thriller that teaches digital safety by letting you practice difficult decisions in a fictional environment.

**Status:** Playable proof-of-concept. **Not** a production Android / Unity build. The current engine is dependency-free JavaScript, designed for validation in any modern browser; porting it to Unity/C# is a separate task.

## Play now

**Simplest:** Open `TRUST_Playable_Demo.html` in a browser. It is a **single self-contained HTML file** (HTML + CSS + engine + story data + UI) that also works offline. It needs no server, login, API key, package installation, or network connection.

**From source:** Open `index.html` in your browser. The source project loads `src/engine.js`, `data/stories.js` and `src/ui.js` as ordinary local scripts. Both versions have identical functionality.

## What's really implemented

- A deterministic, schema-validated, data-driven branching narrative engine (`src/engine.js`)
- Three complete playable cases: bank SMS phishing, pay-to-work scam, and voice impersonation
- Multiple endings and choices; side paths can lead to safe, risky, recovered or verified outcomes
- Inspectable clues and three tracked skills/shields: Evidence / Verification / Protection
- Decision and investigation action log
- Saved current session and best-case results in local browser storage when available
- Responsive phone-simulation UI for desktop and mobile browsers
- Restart, replay, switch cases, and play offline
- Automated engine tests (Node's built-in runner)
- A build script producing the single-file offline playable demo

## Quick verification

```bash
node --test tests/engine.test.js
node tools/build.js
```

No `npm install` required. `node` 18+ is sufficient.

Try this in Node:

```js
const { Engine } = require('./src/engine.js');
require('./data/stories.js');
const game = new Engine(globalThis.TRUST_STORIES, 'bank');
game.inspect('sms-domain');
game.choose('app');
game.choose('support');
game.choose('report');
console.log(game.view().node.headline, game.score);
// You broke the urgency trap. 3
```

## Engine API

```js
new Engine(stories, scenarioId)
engine.start(scenarioId)
engine.view()          // read-only deep snapshot
engine.inspect(clueId) // reveals a clue, may award evidence
engine.choose(id)      // changes scene, records decision, awards shields
engine.exportState()   // JSON-serializable current session
engine.restoreState(saved)
engine.score           // 0–3
engine.ended           // true when current node is an ending
validateStories(stories)
```

See `data/stories.js` to author additional scenarios without editing the engine code.

## Verify the key feature

In **The Bank Alert**, investigate the SMS link and choose: `Open your saved banking app` → `Contact support inside the saved app` → `Report the SMS and protect your account`. You should see **3/3 shields** and a verified ending. Replay, choose the phishing link, and enter the simulated credentials: you should see a different, risky ending.

## Responsible design

All URLs and financial transactions are fictional simulations. The app does not access your real SMS, calls, contacts, accounts, or the internet. It does not collect real credentials or payment information. It is not a substitute for professional cybersecurity advice. Content and learning effectiveness have **not** been independently validated; playtesting and expert review are future work.

## What's *not* implemented

- No actual Unity scene, Unity import pipeline, Android APK, or store-ready build
- No live AI, online services, user accounts, or analytics integrations
- The complete 15-scenario game design has **not** been converted into 15 playable scenarios yet
- No proof yet that players love it, learn from it, or change real-world behavior
- No hosting or public GitHub repository has been created

## Suggested $200 milestone allocation (proposal, not a guarantee)

- $50: validate 3-case playable vertical slice and usability
- $60: port engine to tested C# for Unity + create UI scene and data adapters
- $50: content pipeline, 2–3 more polished cases, testing and accessibility
- $40: user tests, iteration and documentation

Release later milestones only after each deliverable is demonstrated and tested.

## Project structure

```text
TRUST_Proof_Prototype/
  index.html             Browser source version
  data/stories.js        Three playable data-driven stories
  src/engine.js          Standalone deterministic narrative engine
  src/ui.js              Browser UI controller
  src/style.css          Responsive styling
  tests/engine.test.js   Automated engine tests
  tools/build.js         Self-contained HTML build
  package.json           npm test / npm run build
  README.md              Instructions + honest limitations
```

The `TRUST_Playable_Demo.html` file is generated alongside the project folder, outside the source directory, for easy standalone sharing.
