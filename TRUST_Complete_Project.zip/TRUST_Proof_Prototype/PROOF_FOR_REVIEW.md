# TRUST — Proof of Execution (review pack)

## Here is the code, not just a plan

**Run the build:** Open `dist/index.html` locally. The file includes all code, styling and case data. No API key or internet is necessary.

**Run the tests:**

```bash
npm test
# 18 automated tests passing
```

**Verify the best outcome in Case 001:** Inspect the suspicious link, open the saved bank app, contact in-app support, and report the SMS. The result should read **3 / 3 SHIELDS**. Replay and enter the fictional credentials on the phishing page to see an unsafe ending.

**Change the content:** Open `data/stories.js`, edit a scene, refresh `index.html`, and the playable game changes without editing the engine.

## What exists today

| Deliverable | Status | Evidence |
|---|---|---|
| Data-driven branching engine | Implemented | `src/engine.js` |
| 3 playable cases | Implemented | `data/stories.js` |
| Multiple outcomes | Implemented | `nodes` with safe / verified / risky / recovery endings |
| Scoring with evidence, verification, protection | Implemented | `Engine.inspect`, `Engine.choose`, unit tests |
| Progress saving and state restoration | Implemented | localStorage and `Engine.restoreState`, unit tests |
| Browser UI | Implemented | `src/ui.js`, `src/style.css`, `dist/index.html` |
| Automated logic tests | Passing | `tests/engine.test.js` — 18 tests |
| Browser interaction smoke tests | Passing locally | `tests/browser_smoke.py` using Playwright |
| Unity/C# runtime or Android APK | Not built | Separate milestone |
| 15 implemented scenarios | Not built | 3 of 15 playable |
| Public GitHub repository | Not created | The ZIP is shareable source code |

## Suggested response to the $35 objection

> You're right. A milestone breakdown isn't an engine. So I built one.
>
> The attached HTML file is a playable, offline build. It's not a mockup: you can make choices, investigate clues, reach different endings, replay stories, and earn different scores. The source ZIP includes the deterministic narrative engine, three playable scenarios, the content data, and 18 passing automated tests.
>
> Try The Bank Alert. Inspect the sender's link, independently check the saved banking app, contact support, and report the message. You'll reach the verified ending with three shields. Then replay, trust the SMS link, and watch the simulated account-compromise ending. Those are actual engine branches, not scripted presentation slides.
>
> I am **not** claiming this is a finished Unity game or that we have proven product-market fit. I am showing a running vertical-slice prototype and a reusable content architecture. The next $200 allocation would specifically fund porting and validating this engine in Unity, converting more scenarios, and testing whether real players enjoy and learn from it.
>
> $35 was a reasonable valuation for another document. Now judge the artifact, not the pitch.

## Security and limitations

The browser game is fully fictional. There are no real logins, payment links, external requests, or contacts. The automated tests demonstrate logical correctness, not learning efficacy or market demand. To validate social impact, we still need expert content review and a controlled user study.
