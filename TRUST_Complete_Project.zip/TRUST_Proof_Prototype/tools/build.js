const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
let page = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const style = fs.readFileSync(path.join(root, 'src/style.css'), 'utf8');
page = page.replace('<link rel="stylesheet" href="src/style.css" />', `<style>\n${style}\n</style>`);
for (const [src, filename] of [['src/engine.js','src/engine.js'], ['data/stories.js','data/stories.js'], ['src/ui.js','src/ui.js']]) {
  const code = fs.readFileSync(path.join(root, filename), 'utf8');
  page = page.replace(`<script src="${src}"></script>`, `<script>\n${code.replace(/<\/script/gi, '<\\/script')}\n</script>`);
}
fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
fs.writeFileSync(path.join(root, 'dist', 'index.html'), page);
fs.writeFileSync(path.join(root, '..', 'TRUST_Playable_Demo.html'), page);
console.log('Built standalone HTML:', path.join(root, 'dist', 'index.html'), Buffer.byteLength(page), 'bytes');
