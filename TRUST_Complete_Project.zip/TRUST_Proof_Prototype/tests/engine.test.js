const test = require('node:test');
const assert = require('node:assert/strict');
const {Engine, validateStories} = require('../src/engine.js');
require('../data/stories.js');
const stories = globalThis.TRUST_STORIES;
const create = (id = 'bank') => new Engine(stories, id);
function path(engine, steps) {
  for (const [action, value] of steps) {
    if (action === 'inspect') engine.inspect(value);
    else if (action === 'choose') engine.choose(value);
  }
  return engine.view();
}
test('data validates and contains 3 stories', () => {
  assert.equal(validateStories(stories), true);
  assert.deepEqual(stories.map(s => s.id), ['bank', 'job', 'voice']);
});
test('every node and every ending is reachable from the beginning', () => {
  for (const story of stories) {
    const discovered = new Set([story.start]);
    const queue = [story.start];
    while (queue.length) {
      const nodeId = queue.shift();
      for (const next of (story.nodes[nodeId].options || [])) if (!discovered.has(next.to)) {
        discovered.add(next.to);
        queue.push(next.to);
      }
    }
    assert.deepEqual([...discovered].sort(), Object.keys(story.nodes).sort(), story.id);
    assert.ok([...discovered].some(id => story.nodes[id].type === 'ending'));
  }
});
test('bank best route: 3 shields, verified ending, 3 choices', () => {
  const engine = create();
  const v = path(engine, [['inspect','sms-domain'], ['choose','app'], ['inspect','history'], ['choose','support'], ['choose','report']]);
  assert.equal(v.score, 3);
  assert.equal(v.node.id, 'verified');
  assert.equal(v.ended, true);
  assert.equal(v.steps, 3);
});
test('bank unsafe link route: simulated compromise and 0 shields', () => {
  const engine = create();
  const v = path(engine, [['choose','link'], ['choose','enter']]);
  assert.equal(v.score, 0);
  assert.equal(v.compromised, true);
  assert.equal(v.node.outcome, 'risk');
});
test('bank ignores alert: safe but not verified', () => {
  const engine = create();
  const v = path(engine, [['choose','ignore']]);
  assert.equal(v.score, 1);
  assert.equal(v.shields.verification, false);
  assert.equal(v.node.outcome, 'safe');
});
test('bank risky first branch can recover with independent verification', () => {
  const engine = create();
  const v = path(engine, [['choose','link'], ['inspect','otp-request'], ['choose','escape'], ['choose','support'], ['choose','report']]);
  assert.equal(v.score, 3);
  assert.equal(v.compromised, false);
  assert.equal(v.node.outcome, 'case-solved');
});
test('job best route: independent verification before payment', () => {
  const v = path(create('job'), [['inspect','deposit'], ['choose','verify'], ['choose','careers-report']]);
  assert.equal(v.score, 3);
  assert.equal(v.compromised, false);
  assert.equal(v.node.outcome, 'case-solved');
});
test('job risky route: multiple fictional deposits lead to loss', () => {
  const v = path(create('job'), [['choose','pay'], ['choose','again']]);
  assert.equal(v.score, 0);
  assert.equal(v.compromised, true);
  assert.equal(v.node.outcome, 'risk');
});
test('job recovery route earns protection, not verification', () => {
  const v = path(create('job'), [['choose','pay'], ['inspect','second-deposit'], ['choose','recover']]);
  assert.equal(v.score, 2);
  assert.equal(v.compromised, true);
  assert.equal(v.shields.verification, false);
  assert.equal(v.node.outcome, 'recovery');
});
test('voice best route: callback fails then second trusted contact succeeds', () => {
  const v = path(create('voice'), [['inspect','number'], ['choose','callback'], ['choose','family'], ['choose','family-protect']]);
  assert.equal(v.score, 3);
  assert.equal(v.node.outcome, 'case-solved');
});
test('voice personal detail is insufficient verification', () => {
  const v = path(create('voice'), [['choose','question'], ['choose','detail-send']]);
  assert.equal(v.score, 0);
  assert.equal(v.compromised, true);
});
test('inspecting the same evidence twice cannot farm shields or history', () => {
  const engine = create();
  engine.inspect('sms-domain');
  engine.inspect('sms-domain');
  assert.equal(engine.score, 1);
  assert.equal(engine.view().log.length, 1);
  assert.equal(engine.view().clues.length, 1);
});
test('unknown choice, unavailable clue and post-ending action throw', () => {
  const engine = create();
  assert.throws(() => engine.choose('not-real'), /Choice unavailable/);
  assert.throws(() => engine.inspect('nope'), /Clue unavailable/);
  engine.choose('ignore');
  assert.throws(() => engine.choose('app'), /already ended/);
  assert.throws(() => engine.inspect('sms-domain'), /after ending/);
});
test('save/restore retains choices, clues, shields and position', () => {
  const first = create();
  first.inspect('sms-domain');
  first.choose('app');
  const second = create('voice');
  second.restoreState(first.exportState());
  assert.deepEqual(second.view(), first.view());
  second.choose('support');
  assert.equal(first.view().node.id, 'official_app');
});
test('invalid saved node cannot restore', () => {
  const engine = create();
  const state = engine.exportState();
  state.nodeId = '__invalid__';
  assert.throws(() => engine.restoreState(state), /unknown node/);
});
test('view and exportState are defensive copies', () => {
  const engine = create();
  const view = engine.view();
  view.shields.evidence = true;
  view.node.text = 'mutated';
  const state = engine.exportState();
  state.shields.verification = true;
  assert.equal(engine.score, 0);
  assert.notEqual(engine.view().node.text, 'mutated');
});
test('rejects broken transition in data', () => {
  const clone = JSON.parse(JSON.stringify(stories));
  clone[0].nodes.sms.options[0].to = 'nonexistent';
  assert.throws(() => validateStories(clone), /Invalid transition/);
});
test('restarting a scenario clears shields and clues', () => {
  const engine = create();
  engine.inspect('sms-domain');
  engine.start('bank');
  assert.equal(engine.score, 0);
  assert.deepEqual(engine.view().clues, []);
});
