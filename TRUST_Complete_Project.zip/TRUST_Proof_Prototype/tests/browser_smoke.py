from playwright.sync_api import sync_playwright
from pathlib import Path

# Direct navigation is blocked in this sandbox; render the exact self-contained build in the page.
html = (Path(__file__).resolve().parent.parent / 'dist' / 'index.html').read_text()
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page = browser.new_page(viewport={'width':1440,'height':950}, device_scale_factor=1)
    errors=[]
    page.on('pageerror',lambda err: errors.append(str(err)))
    page.set_content(html, wait_until='load')
    assert page.title() == 'TRUST — The Interactive Safety Thriller'
    assert page.locator('#story-title').inner_text() == 'The Bank Alert'
    assert page.locator('.choice').count() == 4
    assert page.locator('.clue-button').count() == 2
    page.screenshot(path=str(Path(__file__).resolve().parent / 'desktop.png'), full_page=True)
    page.get_by_role('button',name='Inspect the verification link').click()
    assert 'Evidence added to your case file' in page.locator('#toast').inner_text()
    page.get_by_role('button',name='Open your saved banking app').click()
    assert page.locator('#app-name').inner_text() == 'SAVED BANK APP'
    page.get_by_role('button',name='Contact support inside the saved app').click()
    page.get_by_role('button',name='Report the SMS and protect your account').click()
    assert '3 / 3 SHIELDS' in page.locator('.result-score').inner_text()
    assert 'You broke the urgency trap.' in page.locator('.ending-card').inner_text()
    assert '1 / 3 CASES PLAYED' in page.locator('#progress-count').inner_text()
    # Opaque about:blank origins cannot use localStorage; resume is covered by engine save/restore unit tests.
    page.get_by_role('button',name='Next case').click()
    assert page.locator('#story-title').inner_text() == 'The Perfect Job'
    page.get_by_role('button',name='Deposit $45').click()
    page.get_by_role('button',name='Stop, preserve records and report').click()
    assert 'You stopped the loss from growing.' in page.locator('.ending-card').inner_text()
    page.screenshot(path=str(Path(__file__).resolve().parent / 'desktop_end.png'), full_page=True)
    assert errors == [], 'JS page errors: '+str(errors)
    page.close()
    mobile = browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1, is_mobile=True, has_touch=True)
    mobile_errors=[]
    mobile.on('pageerror',lambda err: mobile_errors.append(str(err)))
    mobile.set_content(html, wait_until='load')
    assert mobile.locator('#story-title').inner_text() == 'The Bank Alert'
    assert mobile.locator('.choice').count() == 4
    mobile.screenshot(path=str(Path(__file__).resolve().parent / 'mobile.png'), full_page=True)
    assert mobile.evaluate('document.documentElement.scrollWidth <= window.innerWidth + 2'), 'Horizontal overflow'
    assert mobile_errors == [], 'Mobile JS errors: '+str(mobile_errors)
    browser.close()
    print('BROWSER SMOKE PASSED: desktop choices, 3/3 ending, engine persistence (unit-tested), job recovery, mobile responsive, no JS exceptions')
