/* TRUST narrative engine — deterministic, dependency-free, browser + Node compatible. */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.TrustEngine = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const SHIELDS = ['evidence', 'verification', 'protection'];

  function assert(cond, message) { if (!cond) throw new Error(message); }
  function snapshot(value) { return JSON.parse(JSON.stringify(value)); }

  function validateStories(stories) {
    assert(Array.isArray(stories) && stories.length > 0, 'At least one story is required');
    const ids = new Set();
    for (const story of stories) {
      assert(story && typeof story.id === 'string' && story.id, 'Story id missing');
      assert(!ids.has(story.id), 'Duplicate story id: ' + story.id);
      ids.add(story.id);
      assert(story.nodes && typeof story.nodes === 'object', 'Story nodes missing: ' + story.id);
      assert(story.nodes[story.start], 'Missing start node: ' + story.id);
      let endingCount = 0;
      for (const [nodeId, node] of Object.entries(story.nodes)) {
        assert(['scene', 'ending'].includes(node.type), `Invalid type ${story.id}/${nodeId}`);
        assert(typeof node.text === 'string', `Missing text ${story.id}/${nodeId}`);
        if (node.type === 'ending') {
          endingCount++;
          assert(node.outcome && node.debrief, `Ending needs outcome/debrief ${story.id}/${nodeId}`);
          assert(!node.options || node.options.length === 0, 'Ending must not have options');
        } else {
          assert(Array.isArray(node.options) && node.options.length > 0, `No choices ${story.id}/${nodeId}`);
        }
        const options = node.options || [];
        const optionIds = new Set();
        for (const option of options) {
          assert(option.id && option.label && option.to && story.nodes[option.to], `Invalid transition ${story.id}/${nodeId}`);
          assert(!optionIds.has(option.id), `Duplicate option ${story.id}/${nodeId}/${option.id}`);
          optionIds.add(option.id);
          for (const shield of option.shields || []) assert(SHIELDS.includes(shield), 'Unknown shield: ' + shield);
        }
        const clueIds = new Set();
        for (const clue of node.clues || []) {
          assert(clue.id && clue.label && clue.detail, `Invalid clue ${story.id}/${nodeId}`);
          assert(!clueIds.has(clue.id), `Duplicate clue ${story.id}/${nodeId}/${clue.id}`);
          clueIds.add(clue.id);
          if (clue.shield) assert(SHIELDS.includes(clue.shield), 'Unknown clue shield');
        }
      }
      assert(endingCount > 0, 'Story has no ending: ' + story.id);
    }
    return true;
  }

  class Engine {
    constructor(stories, storyId) {
      validateStories(stories);
      this.stories = stories;
      this.storyMap = new Map(stories.map(s => [s.id, s]));
      this.start(storyId || stories[0].id);
    }
    start(storyId) {
      const story = this.storyMap.get(storyId);
      assert(story, 'Unknown story: ' + storyId);
      this.state = {
        storyId, nodeId: story.start,
        shields: { evidence: false, verification: false, protection: false },
        clues: [], log: [], compromised: false, steps: 0
      };
      return this.view();
    }
    get story() { return this.storyMap.get(this.state.storyId); }
    get node() { return this.story.nodes[this.state.nodeId]; }
    get ended() { return this.node.type === 'ending'; }
    get score() { return SHIELDS.filter(k => this.state.shields[k]).length; }
    view() {
      const { storyId, nodeId, shields, clues, log, compromised, steps } = this.state;
      return snapshot({
        story: { id: this.story.id, title: this.story.title, chapter: this.story.chapter,
          eyebrow: this.story.eyebrow, subtitle: this.story.subtitle, accent: this.story.accent,
          icon: this.story.icon, difficulty: this.story.difficulty },
        node: { id: nodeId, ...this.node },
        shields, clues, log, compromised, steps,
        score: this.score, ended: this.ended
      });
    }
    inspect(clueId) {
      assert(!this.ended, 'Cannot inspect after ending');
      const clue = (this.node.clues || []).find(c => c.id === clueId);
      assert(clue, 'Clue unavailable: ' + clueId);
      if (!this.state.clues.includes(clueId)) {
        this.state.clues.push(clueId);
        if (clue.shield) this.state.shields[clue.shield] = true;
        this.state.log.push({ type: 'inspect', at: this.state.nodeId, id: clueId, label: clue.label });
      }
      return { detail: clue.detail, view: this.view() };
    }
    choose(choiceId) {
      assert(!this.ended, 'Scenario already ended');
      const choice = this.node.options.find(c => c.id === choiceId);
      assert(choice, 'Choice unavailable: ' + choiceId);
      const from = this.state.nodeId;
      this.state.nodeId = choice.to;
      this.state.steps += 1;
      if (choice.compromised) this.state.compromised = true;
      for (const shield of choice.shields || []) this.state.shields[shield] = true;
      this.state.log.push({ type: 'choice', at: from, id: choiceId, label: choice.label, to: choice.to });
      return this.view();
    }
    exportState() { return snapshot(this.state); }
    restoreState(saved) {
      // Persistence is local convenience data, not an anti-cheat boundary.
      assert(saved && typeof saved === 'object', 'Invalid save data');
      const story = this.storyMap.get(saved.storyId);
      assert(story && story.nodes[saved.nodeId], 'Save references an unknown node');
      assert(saved.shields && SHIELDS.every(k => typeof saved.shields[k] === 'boolean'), 'Invalid shields');
      assert(Array.isArray(saved.clues) && Array.isArray(saved.log), 'Invalid history');
      assert(typeof saved.steps === 'number' && saved.steps >= 0, 'Invalid steps');
      this.state = snapshot(saved);
      return this.view();
    }
  }
  return { Engine, validateStories, SHIELDS };
});
