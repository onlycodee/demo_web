/* TRUST playable demo UI. Offline-first; no network requests or external tracking. */
(function () {
  'use strict';
  const stories = globalThis.TRUST_STORIES;
  const { Engine } = globalThis.TrustEngine;
  const engine = new Engine(stories);
  const SAVE_KEY = 'trust_demo_progress_v1';
  const SESSION_KEY = 'trust_demo_session_v1';
  const els = {
    caseList: document.querySelector('#case-list'),
    storyLabel: document.querySelector('#story-label'),
    chapterLabel: document.querySelector('#chapter-label'),
    storyTitle: document.querySelector('#story-title'),
    storySubtitle: document.querySelector('#story-subtitle'),
    phone: document.querySelector('#phone-content'),
    appName: document.querySelector('#app-name'),
    sender: document.querySelector('#sender-name'),
    shields: document.querySelector('#shields'),
    clues: document.querySelector('#clues'),
    log: document.querySelector('#log'),
    status: document.querySelector('#status'),
    progress: document.querySelector('#progress-count'),
    badge: document.querySelector('#difficulty'),
    glow: document.querySelector('#phone-glow'),
    toast: document.querySelector('#toast'),
    reset: document.querySelector('#reset-story'),
    guide: document.querySelector('#guide-toggle'),
    guidePanel: document.querySelector('#guide-panel'),
    note: document.querySelector('#scenario-note')
  };
  let progress = {};
  let visibleClue = null;
  try { progress = JSON.parse(localStorage.getItem(SAVE_KEY) || '{}') || {}; } catch (_) { progress = {}; }
  try {
    const saved = JSON.parse(localStorage.getItem(SESSION_KEY) || 'null');
    if (saved) engine.restoreState(saved);
  } catch (_) { /* malformed/stale save: start from beginning */ }

  function escapeHTML(str) {
    return String(str).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  }
  function save() {
    try {
      localStorage.setItem(SESSION_KEY, JSON.stringify(engine.exportState()));
      localStorage.setItem(SAVE_KEY, JSON.stringify(progress));
    } catch (_) { /* private browsing / disabled storage: game still works */ }
  }
  let toastTimer;
  function toast(message) {
    els.toast.textContent = message;
    els.toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => els.toast.classList.remove('show'), 2900);
  }
  function startStory(id) {
    engine.start(id);
    visibleClue = null;
    save();
    render();
  }
  function onChoose(id) {
    const result = engine.choose(id);
    visibleClue = null;
    if (result.ended) {
      const previous = progress[result.story.id] || 0;
      progress[result.story.id] = Math.max(previous, result.score);
    }
    save();
    render();
  }
  function onInspect(id) {
    const priorScroll = els.phone.scrollTop;
    const alreadySeen = engine.view().clues.includes(id);
    const { detail } = engine.inspect(id);
    visibleClue = { id, detail };
    save();
    render();
    els.phone.scrollTop = priorScroll;
    if (!alreadySeen) toast('Evidence added to your case file');
  }
  function renderCases(view) {
    els.caseList.replaceChildren();
    stories.forEach((story, i) => {
      const btn = document.createElement('button');
      const active = story.id === view.story.id;
      btn.className = `case-card ${active ? 'active' : ''}`;
      btn.style.setProperty('--case-accent', story.accent);
      btn.setAttribute('aria-current', active ? 'true' : 'false');
      const best = progress[story.id];
      btn.innerHTML = `<span class="case-number">0${i + 1}</span><span class="case-text"><strong>${escapeHTML(story.title)}</strong><small>${escapeHTML(story.difficulty)}</small></span><span class="case-score">${best === undefined ? '○○○' : '◆'.repeat(best) + '◇'.repeat(3 - best)}</span>`;
      btn.addEventListener('click', () => startStory(story.id));
      els.caseList.append(btn);
    });
  }
  function renderClues(view) {
    els.clues.replaceChildren();
    const all = view.node.clues || [];
    if (view.ended) {
      const p = document.createElement('div');
      p.className = 'empty-clues';
      p.textContent = `${view.clues.length} clue${view.clues.length === 1 ? '' : 's'} investigated during this case.`;
      els.clues.append(p);
    } else if (!all.length) {
      const p = document.createElement('div');
      p.className = 'empty-clues';
      p.textContent = 'No new leads here. Make your decision below.';
      els.clues.append(p);
    } else {
      all.forEach((clue) => {
        const seen = view.clues.includes(clue.id);
        const btn = document.createElement('button');
        btn.className = `clue-button ${seen ? 'seen' : ''}`;
        btn.innerHTML = `<span class="clue-symbol">${seen ? '✓' : '?'}</span><span>${escapeHTML(clue.label)}</span><span class="clue-arrow">↗</span>`;
        btn.addEventListener('click', () => onInspect(clue.id));
        els.clues.append(btn);
      });
    }
    const revealed = document.querySelector('#clue-reveal');
    revealed.textContent = visibleClue ? visibleClue.detail : 'Tap a clue to examine it. Strong decisions begin with evidence.';
    revealed.classList.toggle('is-revealed', Boolean(visibleClue));
  }
  function renderPhone(view) {
    els.phone.replaceChildren();
    els.appName.textContent = view.node.app || 'TRUST';
    els.sender.textContent = view.node.sender || view.story.title;
    if (view.ended) {
      const isSolved = view.node.outcome === 'case-solved';
      const isRisk = view.node.outcome === 'risk';
      const card = document.createElement('div');
      card.className = `ending-card ${isRisk ? 'is-risk' : isSolved ? 'is-solved' : 'is-safe'}`;
      card.innerHTML = `
        <div class="ending-symbol">${isRisk ? '!' : isSolved ? '✓' : '↗'}</div>
        <div class="ending-eyebrow">${isRisk ? 'SIMULATED CONSEQUENCE' : isSolved ? 'INVESTIGATION COMPLETE' : 'DECISION COMPLETE'}</div>
        <h2>${escapeHTML(view.node.headline)}</h2>
        <p>${escapeHTML(view.node.text)}</p>
        <div class="result-score"><strong>${view.score} <span>/ 3 SHIELDS</span></strong><small>${['Evidence', 'Verification', 'Protection'].filter(k => view.shields[k.toLowerCase()]).join(' · ') || 'Try an alternate path'}</small></div>
        <div class="lesson-title">THE REVEAL</div>
        <p class="lesson-copy">${escapeHTML(view.node.debrief)}</p>
        <div class="lesson-title">TAKE INTO REAL LIFE</div>
        <p class="lesson-copy">${escapeHTML(view.node.habit)}</p>
      `;
      const actionArea = document.createElement('div');
      actionArea.className = 'ending-actions';
      const again = document.createElement('button');
      again.className = 'choice primary';
      again.textContent = '↻  Replay this case';
      again.addEventListener('click', () => startStory(view.story.id));
      const next = document.createElement('button');
      next.className = 'choice';
      next.textContent = 'Next case  →';
      next.addEventListener('click', () => {
        const ix = stories.findIndex(s => s.id === view.story.id);
        startStory(stories[(ix + 1) % stories.length].id);
      });
      actionArea.append(again, next);
      els.phone.append(card, actionArea);
    } else {
      const trace = document.createElement('div');
      trace.className = 'trace-line';
      trace.innerHTML = `<span class="trace-dot"></span><span>${escapeHTML(view.node.mood || 'NEW MESSAGE')}</span><span class="trace-time">${view.node.time || 'NOW'}</span>`;
      const message = document.createElement('div');
      message.className = 'message-card';
      const from = document.createElement('div');
      from.className = 'message-from';
      from.textContent = view.node.sender || 'Notification';
      const text = document.createElement('p');
      text.className = 'message-text';
      text.textContent = view.node.text;
      message.append(from, text);
      const context = document.createElement('div');
      context.className = 'context-card';
      context.innerHTML = `<span class="context-label">SITUATION</span><p>${escapeHTML(view.node.context || '')}</p>`;
      const mobileClues = document.createElement('div');
      mobileClues.className = 'mobile-investigate';
      if ((view.node.clues || []).length) {
        const clueHeading = document.createElement('div');
        clueHeading.className = 'choice-heading';
        clueHeading.textContent = 'INVESTIGATE BEFORE DECIDING';
        mobileClues.append(clueHeading);
        for (const clue of view.node.clues) {
          const seen = view.clues.includes(clue.id);
          const clueButton = document.createElement('button');
          clueButton.className = `mobile-clue-button ${seen ? 'seen' : ''}`;
          clueButton.textContent = `${seen ? '✓' : '⌕'}  ${clue.label}`;
          clueButton.addEventListener('click', () => onInspect(clue.id));
          mobileClues.append(clueButton);
        }
        if (visibleClue) {
          const clueDetail = document.createElement('p');
          clueDetail.className = 'mobile-clue-detail';
          clueDetail.textContent = visibleClue.detail;
          mobileClues.append(clueDetail);
        }
      }
      const choiceLabel = document.createElement('div');
      choiceLabel.className = 'choice-heading';
      choiceLabel.textContent = 'WHAT DO YOU DO?';
      const choices = document.createElement('div');
      choices.className = 'choices';
      view.node.options.forEach((choice, index) => {
        const button = document.createElement('button');
        button.className = 'choice';
        button.innerHTML = `<span class="choice-index">${String.fromCharCode(65 + index)}</span><span>${escapeHTML(choice.label)}</span><span class="choice-next">↗</span>`;
        button.addEventListener('click', () => onChoose(choice.id));
        choices.append(button);
      });
      els.phone.append(trace, message, context, mobileClues, choiceLabel, choices);
    }
  }
  function render() {
    const view = engine.view();
    document.documentElement.style.setProperty('--accent', view.story.accent);
    els.storyLabel.textContent = view.story.eyebrow;
    els.chapterLabel.textContent = view.story.chapter;
    els.storyTitle.textContent = view.story.title;
    els.storySubtitle.textContent = view.story.subtitle;
    els.badge.textContent = view.story.difficulty;
    els.status.textContent = view.ended ? 'CASE COMPLETE' : 'INVESTIGATION LIVE';
    els.status.classList.toggle('complete', view.ended);
    els.note.textContent = 'Fictional simulation · No real money, websites, or accounts involved';
    els.progress.textContent = `${Object.keys(progress).length} / ${stories.length} CASES PLAYED`;
    els.shields.replaceChildren();
    for (const [key, icon] of [['evidence','⌕'], ['verification','◎'], ['protection','◇']]) {
      const pill = document.createElement('div');
      pill.className = `shield ${view.shields[key] ? 'earned' : ''}`;
      pill.innerHTML = `<strong>${icon}</strong><span>${key}</span><b>${view.shields[key] ? '✓' : '—'}</b>`;
      els.shields.append(pill);
    }
    els.log.replaceChildren();
    const recent = [...view.log].reverse().slice(0, 4);
    if (!recent.length) {
      const p = document.createElement('p');
      p.className = 'muted';
      p.textContent = 'Your investigation will appear here.';
      els.log.append(p);
    } else {
      for (const entry of recent) {
        const p = document.createElement('div');
        p.className = 'log-item';
        p.innerHTML = `<span>${entry.type === 'inspect' ? '⌕' : '↳'}</span><span>${escapeHTML(entry.label)}</span>`;
        els.log.append(p);
      }
    }
    renderCases(view);
    renderClues(view);
    renderPhone(view);
    els.phone.scrollTop = 0;
  }
  els.reset.addEventListener('click', () => startStory(engine.view().story.id));
  els.guide.addEventListener('click', () => {
    const isOpen = els.guidePanel.classList.toggle('open');
    els.guide.setAttribute('aria-expanded', String(isOpen));
  });
  render();
})();
