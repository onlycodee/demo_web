// Safe fictional cases inspired by TRUST's scenario design. No real domains, accounts or calls.
(function (root) {
  root.TRUST_STORIES = [
    {
      id: 'bank', title: 'The Bank Alert', chapter: 'CHAPTER 01 / THE INBOX',
      eyebrow: 'CASE 001', subtitle: 'A message says your savings are at risk.',
      accent: '#5de0bb', icon: '◈', difficulty: 'Beginner', start: 'sms',
      nodes: {
        sms: {
          type: 'scene', app: 'MESSAGES', sender: 'Account Security · Unknown',
          time: '09:41', mood: 'URGENT',
          text: 'A suspicious $680 transfer was detected. Your account will be locked in 10 minutes. Verify now at secure-check.example.test',
          context: 'You have an existing banking app on your phone. The SMS arrived from a number you do not recognize.',
          clues: [
            { id: 'sms-domain', label: 'Inspect the verification link', shield: 'evidence', detail: 'The link is on example.test — not a trusted address you obtained independently. A polished website or HTTPS lock alone does not prove who operates it.' },
            { id: 'sms-sender', label: 'Inspect the sender', detail: 'The message comes from an unfamiliar number. Sender names and numbers can be spoofed.' }
          ],
          options: [
            { id: 'link', label: 'Open the urgent verification link', to: 'fake_site' },
            { id: 'app', label: 'Open your saved banking app', to: 'official_app' },
            { id: 'reply', label: 'Reply: “Are you really the bank?”', to: 'reply' },
            { id: 'ignore', label: 'Delete the SMS and move on', to: 'ignored', shields: ['protection'] }
          ]
        },
        reply: {
          type: 'scene', app: 'MESSAGES', sender: 'Account Security · Unknown', mood: 'PRESSURE',
          text: 'Yes, this is the bank. If you delay, we cannot protect your savings. Verify immediately.',
          context: 'The sender insists they are legitimate. The person making the claim has also provided the “proof.”',
          clues: [{ id: 'self-claim', label: 'Examine the reply', shield: 'evidence', detail: 'A sender confirming their own identity adds no independent evidence.' }],
          options: [
            { id: 'reply-link', label: 'Follow their link', to: 'fake_site' },
            { id: 'reply-app', label: 'Check through the saved app', to: 'official_app' }
          ]
        },
        fake_site: {
          type: 'scene', app: 'BROWSER / SIMULATION', sender: 'SECURE ACCOUNT PORTAL', mood: 'DANGER',
          text: 'Enter your username, password and one-time security code to cancel the transfer.',
          context: 'The fictional page looks professional. Nothing here connects to a real bank.',
          clues: [{ id: 'otp-request', label: 'Inspect the code request', shield: 'evidence', detail: 'A site reached through an unsolicited message asks for a one-time code. This can enable account takeover.' }],
          options: [
            { id: 'enter', label: 'Enter the requested credentials (simulated)', to: 'account_risk', compromised: true },
            { id: 'escape', label: 'Close the page; use the saved app', to: 'official_app', shields: ['protection'] }
          ]
        },
        official_app: {
          type: 'scene', app: 'SAVED BANK APP', sender: 'Overview', mood: 'CALM',
          text: 'Current balance unchanged. No pending $680 transfer appears in your transaction history.',
          context: 'You opened an app you had already installed, rather than following the sender’s link.',
          clues: [{ id: 'history', label: 'Review the transaction history', shield: 'evidence', detail: 'Your transaction history does not show the alleged transfer. This helps, but a support check can resolve uncertainty.' }],
          options: [
            { id: 'support', label: 'Contact support inside the saved app', to: 'official_support', shields: ['verification'] },
            { id: 'stop', label: 'Close everything; share nothing', to: 'protected', shields: ['protection'] },
            { id: 'back', label: 'Trust the SMS link instead', to: 'fake_site' }
          ]
        },
        official_support: {
          type: 'scene', app: 'IN-APP SUPPORT', sender: 'Verified support', mood: 'VERIFIED',
          text: 'We did not send that SMS. There is no matching transfer. Please report the suspicious message and never share a one-time code.',
          context: 'You used an independent channel you already trusted. Now you know the message was fraudulent.',
          clues: [],
          options: [
            { id: 'report', label: 'Report the SMS and protect your account', to: 'verified', shields: ['protection'] },
            { id: 'done', label: 'Close the conversation safely', to: 'protected', shields: ['protection'] }
          ]
        },
        verified: { type: 'ending', app: 'CASE CLOSED', sender: 'Investigation complete', outcome: 'case-solved', headline: 'You broke the urgency trap.', text: 'You verified the alert through a trusted app, not through the message that frightened you.', debrief: 'Urgency is a tactic, not evidence. Open an independently trusted channel before taking action.', habit: 'Open your saved app or contact a verified number — never use contact details supplied in a suspicious message.' },
        protected: { type: 'ending', app: 'CASE CLOSED', sender: 'Safe exit', outcome: 'safe', headline: 'You protected your account.', text: 'You did not provide credentials or send money. The question is whether you independently resolved the alert.', debrief: 'Safety matters more than speed. Verification gives stronger certainty than ignoring everything.', habit: 'When an alert matters, verify independently.' },
        ignored: { type: 'ending', app: 'CASE CLOSED', sender: 'Safe exit', outcome: 'safe', headline: 'You avoided the link.', text: 'No information was shared. But you did not confirm whether your account actually had a problem.', debrief: 'Avoiding a suspicious link is good. Independently verifying a potentially serious alert is better.', habit: 'Use the saved bank app to check important claims.' },
        account_risk: { type: 'ending', app: 'CASE CLOSED', sender: 'Simulated loss', outcome: 'risk', headline: 'The page was a trap.', text: 'In this fictional simulation, an attacker captured the account details and attempted a takeover.', debrief: 'A convincing page and countdown can still be fraudulent. Recovery would involve contacting the bank through a known channel and securing the account.', habit: 'Never enter account credentials or one-time codes on pages reached through unexpected messages.' }
      }
    },
    {
      id: 'job', title: 'The Perfect Job', chapter: 'CHAPTER 02 / THE HUMAN FACTOR',
      eyebrow: 'CASE 002', subtitle: 'You earned $5. Why must you pay to withdraw?',
      accent: '#ffc979', icon: '◇', difficulty: 'Intermediate', start: 'recruiter',
      nodes: {
        recruiter: {
          type: 'scene', app: 'WORKCHAT', sender: 'Mira · Remote Recruiting', mood: 'OPPORTUNITY',
          text: 'Amazing job on your first product-review task! Your fictional wallet has $5. Deposit $45 to unlock premium tasks and withdraw your earnings.',
          context: 'You were promised up to $80 a day for easy remote work. The first tiny reward has just arrived.',
          clues: [
            { id: 'deposit', label: 'Inspect the withdrawal condition', shield: 'evidence', detail: 'A legitimate wage payment should not require you to deposit your own money to unlock withdrawal.' },
            { id: 'recruiter-domain', label: 'Inspect the recruiter profile', detail: 'The profile claims to represent a well-known company, but it is not linked to a verified company channel.' }
          ],
          options: [
            { id: 'pay', label: 'Deposit $45 (fictional money)', to: 'wallet', compromised: true },
            { id: 'verify', label: 'Check the official careers page', to: 'careers', shields: ['verification'] },
            { id: 'proof', label: 'Ask for screenshots of paid workers', to: 'testimonials' },
            { id: 'leave', label: 'Decline and leave the conversation', to: 'job_safe', shields: ['protection'] }
          ]
        },
        testimonials: {
          type: 'scene', app: 'WORKCHAT', sender: 'Mira · Remote Recruiting', mood: 'PRESSURE',
          text: 'Look! Five employees made $300 today. Everyone is doing it. Deposit now before the premium slots run out.',
          context: 'Screenshots were supplied by the same person asking for money.',
          clues: [{ id: 'screenshots', label: 'Inspect the testimonials', shield: 'evidence', detail: 'Screenshots and success stories supplied by a recruiter are not independent proof that a company or job is real.' }],
          options: [
            { id: 'proof-pay', label: 'Pay the $45 deposit', to: 'wallet', compromised: true },
            { id: 'proof-verify', label: 'Search the official employer channel', to: 'careers', shields: ['verification'] },
            { id: 'proof-leave', label: 'Refuse to pay', to: 'job_safe', shields: ['protection'] }
          ]
        },
        wallet: {
          type: 'scene', app: 'EARNINGS WALLET / SIMULATION', sender: 'Balance: $210', mood: 'DANGER',
          text: 'Congratulations! You now have $210. To withdraw it, send an additional $120 security deposit within 5 minutes.',
          context: 'You have already spent fictional money. The new request uses sunk-cost pressure to make another payment seem reasonable.',
          clues: [{ id: 'second-deposit', label: 'Review the escalating deposits', shield: 'evidence', detail: 'The rules changed immediately after you paid. Repeated pay-to-withdraw requests are a major warning sign.' }],
          options: [
            { id: 'again', label: 'Pay again to recover your balance', to: 'job_risk' },
            { id: 'recover', label: 'Stop, preserve records and report', to: 'job_recovery', shields: ['protection'] }
          ]
        },
        careers: {
          type: 'scene', app: 'OFFICIAL CAREERS PAGE / SIMULATION', sender: 'Employer website', mood: 'VERIFIED',
          text: 'No remote review-task positions are listed. A verified recruitment contact confirms the chat account is not affiliated with the company.',
          context: 'This result came from a channel you reached independently, not a link provided by the recruiter.',
          clues: [{ id: 'careers-clue', label: 'Compare the job listing', shield: 'evidence', detail: 'The role, salary promise and required deposit do not match the employer’s documented recruitment process.' }],
          options: [
            { id: 'careers-report', label: 'Refuse the deposit and report the account', to: 'job_verified', shields: ['protection'] },
            { id: 'careers-ignore', label: 'Leave without depositing', to: 'job_safe', shields: ['protection'] }
          ]
        },
        job_verified: { type: 'ending', app: 'CASE CLOSED', sender: 'Investigation complete', outcome: 'case-solved', headline: 'You spotted the pay-to-work trap.', text: 'You checked the employer independently and refused the deposit.', debrief: 'A small initial payment can be bait for much larger demands. Testimonials from the recruiter do not establish legitimacy.', habit: 'Verify job listings on independently reached company channels. Be extremely cautious about pay-to-work demands.' },
        job_safe: { type: 'ending', app: 'CASE CLOSED', sender: 'Safe exit', outcome: 'safe', headline: 'You kept your money.', text: 'You refused to finance your own supposed employment. Checking the source could give stronger confidence.', debrief: 'Real opportunities do not become more legitimate because someone promises instant earnings.', habit: 'Do not deposit funds to unlock wages.' },
        job_recovery: { type: 'ending', app: 'CASE CLOSED', sender: 'Recovery decision', outcome: 'recovery', headline: 'You stopped the loss from growing.', text: 'You made one risky fictional deposit, then refused to chase it with another.', debrief: 'After a mistake, the next decision still matters. Stop payments, preserve evidence, and use trusted reporting channels.', habit: 'Never send another payment just to “recover” the last one.' },
        job_risk: { type: 'ending', app: 'CASE CLOSED', sender: 'Simulated loss', outcome: 'risk', headline: 'The wallet balance was bait.', text: 'The fictional platform demanded new deposits and the displayed balance remained inaccessible.', debrief: 'Sunk costs push people to chase losses. The safe exit is to stop; do not pay again to access imaginary earnings.', habit: 'Treat escalating deposits as a stop signal.' }
      }
    },
    {
      id: 'voice', title: 'The Voice from Home', chapter: 'CHAPTER 03 / TRUST & IDENTITY',
      eyebrow: 'CASE 003', subtitle: 'It sounds exactly like your brother.',
      accent: '#baadff', icon: '◎', difficulty: 'Advanced', start: 'call',
      nodes: {
        call: {
          type: 'scene', app: 'INCOMING CALL / TRANSCRIPT', sender: 'Unknown number', mood: 'EMERGENCY',
          text: '“Hey. It’s Sam. I had an accident. I’m okay, but send $300 right now for paperwork. My phone broke. Please don’t tell Mom — she’ll panic.”',
          context: 'The voice sounds like your brother, including a familiar laugh. The caller is asking you to act without involving anyone else.',
          clues: [
            { id: 'number', label: 'Inspect caller ID', shield: 'evidence', detail: 'The caller’s number is not in your saved contacts. Caller ID and convincing voices are not proof of identity.' },
            { id: 'secrecy', label: 'Inspect the request for secrecy', detail: 'The caller discourages checking with family members. Isolation is often used to prevent verification.' }
          ],
          options: [
            { id: 'send', label: 'Transfer $300 (fictional money)', to: 'voice_risk', compromised: true },
            { id: 'callback', label: 'Hang up and call Sam’s saved number', to: 'sam_phone', shields: ['verification'] },
            { id: 'question', label: 'Ask a question only Sam might know', to: 'personal_detail' },
            { id: 'hangup', label: 'Hang up and do nothing', to: 'voice_safe', shields: ['protection'] }
          ]
        },
        personal_detail: {
          type: 'scene', app: 'CALL / TRANSCRIPT', sender: 'Unknown number', mood: 'PRESSURE',
          text: '“Remember our trip to the lake last summer? You posted pictures. Come on, please send it now.”',
          context: 'The answer contains a true detail — but one that was visible on public social media.',
          clues: [{ id: 'public-detail', label: 'Check how they could know', shield: 'evidence', detail: 'Personal trivia may be public or leaked. Ask through a channel established before this urgent request.' }],
          options: [
            { id: 'detail-send', label: 'Trust the personal detail and send funds', to: 'voice_risk', compromised: true },
            { id: 'detail-call', label: 'Call the saved number instead', to: 'sam_phone', shields: ['verification'] }
          ]
        },
        sam_phone: {
          type: 'scene', app: 'CONTACTS / SAVED NUMBER', sender: 'Calling Sam', mood: 'UNCERTAIN',
          text: 'No answer. The call goes to voicemail. You still cannot tell whether an emergency is real.',
          context: 'Independent verification was the right instinct, but the first attempt did not resolve the question.',
          clues: [{ id: 'voicemail', label: 'Inspect contact details', shield: 'evidence', detail: 'You called the previously saved number, not the caller’s requested callback. No answer is not evidence either way.' }],
          options: [
            { id: 'family', label: 'Call a trusted family contact', to: 'family', shields: ['verification'] },
            { id: 'panic', label: 'Give in and send money', to: 'voice_risk', compromised: true },
            { id: 'wait', label: 'Decline payment until you verify', to: 'voice_safe', shields: ['protection'] }
          ]
        },
        family: {
          type: 'scene', app: 'FAMILY CONTACT', sender: 'Mom · Saved contact', mood: 'VERIFIED',
          text: '“Sam is downstairs making breakfast. I can hand him the phone.” Sam confirms he never called you.',
          context: 'A separate, already trusted channel resolves the story. Caring about someone and verifying their claim are compatible.',
          clues: [],
          options: [
            { id: 'family-protect', label: 'Block/report the caller and warn Sam', to: 'voice_verified', shields: ['protection'] },
            { id: 'family-safe', label: 'End the call without sending funds', to: 'voice_safe', shields: ['protection'] }
          ]
        },
        voice_verified: { type: 'ending', app: 'CASE CLOSED', sender: 'Investigation complete', outcome: 'case-solved', headline: 'You verified the person, not the voice.', text: 'The familiar voice was part of an impersonation attempt. Your independent callback exposed it.', debrief: 'Voice imitation and leaked personal details can make a false call feel real. Use a trusted channel to verify urgent requests.', habit: 'Call back a saved number or contact someone else you already know and trust.' },
        voice_safe: { type: 'ending', app: 'CASE CLOSED', sender: 'Safe exit', outcome: 'safe', headline: 'You resisted the pressure.', text: 'You did not transfer money. If a real emergency remains possible, contact appropriate trusted people or emergency services.', debrief: 'Verification protects people without dismissing genuine emergencies.', habit: 'Stay reachable and helpful — but verify payment instructions independently.' },
        voice_risk: { type: 'ending', app: 'CASE CLOSED', sender: 'Simulated loss', outcome: 'risk', headline: 'The voice was not Sam.', text: 'In this fictional simulation, the transfer went to an impostor. Sam was safe at home.', debrief: 'A familiar voice and private-sounding detail were not independent identity verification.', habit: 'Treat unexpected payment requests as unverified until you confirm by another known channel.' }
      }
    }
  ];
})(typeof globalThis !== 'undefined' ? globalThis : this);
